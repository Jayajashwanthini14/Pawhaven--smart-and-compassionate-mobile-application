import 'package:flutter/material.dart';

import '../Adopters/Adopter_Homescreen.dart';
import '../Petgiver/PetGiver_homepage.dart';
import '../Shelter/Shelter_HomePage.dart';
import '../databasehelper/db_RegisLogin.dart';

import 'SignupPage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool showPassword = false;

  Future<void> _loginUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() => isLoading = true);

      try {
        var user = await DatabaseHelper.instance.loginUser(
          phoneController.text.trim(),
          passwordController.text.trim(),
        );

        if (user != null) {
          String role = user['role'];
          _navigateToDashboard(role);
        } else {
          _showDialog('Error', 'Invalid phone number or password.');
        }
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _navigateToDashboard(String role) {
    Widget targetPage;
    if (role == 'Adopter') {
      targetPage =  const AdopterHomepage(username: '',);
    } else if (role == 'Shelter') {
      targetPage = const ShelterHome(username: '',);
    } else {
      targetPage = const PetgiverHomepage(username: '',);
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => targetPage),
    );
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title, style: const TextStyle(color: Colors.red)),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.orangeAccent.shade100, Colors.orangeAccent.shade200],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.all(25.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 10,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Login',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrangeAccent,
                          ),
                        ),
                        const SizedBox(height: 20),
                        _buildTextField(phoneController, 'Phone Number', Icons.phone, isPhone: true),
                        const SizedBox(height: 15),
                        _buildTextField(passwordController, 'Password', Icons.lock, isPassword: true),
                        const SizedBox(height: 20),
                        _buildLoginButton(),
                        const SizedBox(height: 15),
                        TextButton(
                          onPressed: () => Navigator.pushReplacement(
                              context, MaterialPageRoute(builder: (context) => const SignupPage())),
                          child: const Text('Don’t have an account? Sign up', style: TextStyle(color: Colors.blueGrey, fontSize: 16)),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller,
      String label,
      IconData icon, {
        bool isPassword = false,
        bool isPhone = false,
      }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.orangeAccent),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
        suffixIcon: isPassword
            ? IconButton(
          icon: Icon(showPassword ? Icons.visibility : Icons.visibility_off, color: Colors.pinkAccent),
          onPressed: () => setState(() => showPassword = !showPassword),
        )
            : null,
      ),
      obscureText: isPassword && !showPassword,
      keyboardType: isPhone ? TextInputType.phone : TextInputType.text,
      validator: (value) {
        if (value!.trim().isEmpty) return '$label is required.';
        if (isPhone && !RegExp(r'^\d{10}$').hasMatch(value)) return 'Enter a valid 10-digit phone number.';
        return null;
      },
    );
  }

  Widget _buildLoginButton() {
    return ElevatedButton(
      onPressed: isLoading ? null : _loginUser,
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 60),
        backgroundColor: Colors.orangeAccent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        elevation: 5,
      ),
      child: isLoading
          ? const CircularProgressIndicator(color: Colors.white)
          : const Text('Login', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
    );
  }
}
