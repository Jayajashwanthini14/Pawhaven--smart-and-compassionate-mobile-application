import 'package:flutter/material.dart';
import 'dart:io';

import '../../databasehelper/db_helper.dart';
import '../viewscreens/adoptionform.dart';
import '../viewscreens/favoritespage.dart';
import 'animalsdetailsadopt.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final ValueNotifier<List<Map<String, dynamic>>> _filteredAnimals =
  ValueNotifier<List<Map<String, dynamic>>>([]);
  String _selectedSortOption = 'None';
  final List<String> _sortOptions = ['None', 'Size', 'Location', 'Breed', 'Gender'];

  @override
  void initState() {
    super.initState();
    _loadAnimals();
  }

  Future<void> _loadAnimals() async {
    final animals = await DatabaseHelper.instance.fetchAnimals();
    _filteredAnimals.value = animals;
  }

  void _filterAndSortAnimals(String query, String sortOption) {
    final lowercaseQuery = query.toLowerCase();

    DatabaseHelper.instance.fetchAnimals().then((animals) {
      final filtered = animals.where((animal) {
        final title = animal['title']?.toLowerCase() ?? '';
        final description = animal['description']?.toLowerCase() ?? '';
        final breed = animal['breed']?.toLowerCase() ?? '';
        final location = animal['location']?.toLowerCase() ?? '';
        return title.contains(lowercaseQuery) ||
            description.contains(lowercaseQuery) ||
            breed.contains(lowercaseQuery) ||
            location.contains(lowercaseQuery);
      }).toList();

      filtered.sort((a, b) {
        switch (sortOption) {
          case 'Size':
            return (a['size'] ?? '').compareTo(b['size'] ?? '');
          case 'Location':
            return (a['location'] ?? '').compareTo(b['location'] ?? '');
          case 'Breed':
            return (a['breed'] ?? '').compareTo(b['breed'] ?? '');
          case 'Gender':
            return (a['gender'] ?? '').compareTo(b['gender'] ?? '');
          default:
            return 0;
        }
      });

      _filteredAnimals.value = filtered;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _filteredAnimals.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search Animals'),
        backgroundColor: Colors.pinkAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => const FavoritesPage()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    labelText: 'Search for animals',
                    hintText: 'search for animals',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  onChanged: (query) => _filterAndSortAnimals(query, _selectedSortOption),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Sort by:', style: TextStyle(fontSize: 16),
                    ),
                    DropdownButton<String>(
                      value: _selectedSortOption,
                      items: _sortOptions
                          .map((option) => DropdownMenuItem(
                        value: option, child: Text(option),
                      ))
                          .toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedSortOption = value!;
                          _filterAndSortAnimals(
                              _searchController.text, _selectedSortOption);
                        });
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ValueListenableBuilder<List<Map<String, dynamic>>>(
              valueListenable: _filteredAnimals,
              builder: (context, animals, child) {
                if (animals.isEmpty) {
                  return const Center(
                    child: Text(
                      '', style: TextStyle(fontSize: 16, color: Colors.black54),
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(8.0),
                  itemCount: animals.length,
                  itemBuilder: (context, index) {
                    return AnimalCard(animal: animals[index]);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class AnimalCard extends StatelessWidget {
  final Map<String, dynamic> animal;

  const AnimalCard({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    final isFavorite = animal['favorite'] == 1;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context, MaterialPageRoute(
            builder: (context) => Detailshere(animal: animal),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            _buildAnimalImage(animal['imagePath']),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      animal['title'] ?? 'Unnamed Animal',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16,
                      ),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Breed: ${animal['breed'] ?? 'Unknown'}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    Text(
                      'Gender: ${animal['gender'] ?? 'Unknown'}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Size: ${animal['size'] ?? 'Not specified'}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Location: ${animal['location'] ?? 'Not specified'}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _navigateToAdoptionForm(context),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Adopt Now', style: TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => _toggleFavoriteStatus(context, isFavorite),
                          icon: Icon(
                            isFavorite ? Icons.favorite : Icons.favorite_border, color: Colors.redAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimalImage(String? imagePath) {
    return ClipRRect(
      borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
      child: imagePath != null && File(imagePath).existsSync()
          ? Image.file(
        File(imagePath),
        width: 120, height: 120, fit: BoxFit.cover,
      )
          : Container(
        width: 120, height: 120, color: Colors.grey,
        child: const Icon(Icons.pets, size: 60, color: Colors.white),
      ),
    );
  }

  void _navigateToAdoptionForm(BuildContext context) {
    Navigator.push(
      context, MaterialPageRoute(builder: (context) => const PetAdoptionForm()),
    );
  }

  Future<void> _toggleFavoriteStatus(BuildContext context, bool isFavorite) async {
    final newStatus = !isFavorite;
    await DatabaseHelper.instance.updateFavoriteStatus(animal['id'], newStatus);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(newStatus
            ? '${animal['title']} added to favorites!'
            : '${animal['title']} removed from favorites!'),
      ),
    );
  }
}
