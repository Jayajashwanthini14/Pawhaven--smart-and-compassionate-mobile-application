import 'dart:io';
import 'package:flutter/material.dart';
import '../../databasehelper/db_helper.dart';
import '../viewscreens/adoptionform.dart';
import '../viewscreens/favoritespage.dart';
import 'animalsdetailsadopt.dart';

class AvailabilityScreen extends StatefulWidget {
  final bool showAppBar;

  const AvailabilityScreen({super.key, this.showAppBar = true });

  @override
  State<AvailabilityScreen> createState() => _AvailabilityScreenState();
}

class _AvailabilityScreenState extends State<AvailabilityScreen> {
  Future<List<Map<String, dynamic>>> fetchAnimals() async {
    return await DatabaseHelper.instance.fetchAnimals();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('pass the paw forward'),
        backgroundColor: Colors.white70,
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => const FavoritesPage(),
                ),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchAnimals(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No animals available.'));
          } else {
            final animals = snapshot.data!;
            return GridView.builder(
              padding: EdgeInsets.zero,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12.0,
                mainAxisSpacing: 12.0, childAspectRatio: 0.8,
              ),
              itemCount: animals.length,
              itemBuilder: (context, index) {
                final animal = animals[index];
                final imagePath = animal['imagePath'];
                final isFavorite = animal['favorite'] == 1;

                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Detailshere(animal: animal),
                      ),
                    );
                  },
                  child: Card(
                    elevation: 8,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                              child: imagePath != null && File(imagePath).existsSync()
                                  ? Image.file(
                                File(imagePath),
                                width: double.infinity, height: double.infinity, fit: BoxFit.cover,
                              )
                                  : Container(
                                color: Colors.grey[300], height: double.infinity,
                                child: const Icon(
                                  Icons.image, size: 50, color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12.0, vertical: 6.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                animal['animalType'] == 'Accessory'
                                    ? animal['productName'] ?? 'Unnamed Product'
                                    : animal['title'] ?? 'Unnamed Animal',
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Type: ${animal['animalType']}',
                                style: const TextStyle(fontSize: 12, color: Colors.grey),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '₹${animal['price']}',
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.green),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12.0, vertical: 6.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconButton(icon: Icon(
                                  isFavorite
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: Colors.red, size: 20,
                                ),
                                onPressed: () async {
                                  await DatabaseHelper.instance
                                      .updateFavoriteStatus(animal['id'], !isFavorite,
                                  );
                                  setState(() {});
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        isFavorite
                                            ? '${animal['title']} removed from favorites.'
                                            : '${animal['title']} added to favorites.',
                                      ),
                                    ),
                                  );
                                },
                              ),
                              animal['animalType'] == 'Accessory'
                                  ? TextButton(
                                onPressed: () {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                                        content: Text('Item purchased successfully!')),
                                  );
                                },
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 6.0, horizontal: 10.0),
                                  backgroundColor: Colors.teal.withOpacity(0.2), shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: const Text(
                                  'Buy Now',
                                  style: TextStyle(color: Colors.teal, fontSize: 12, fontWeight: FontWeight.bold),
                                ),
                              )
                                  : TextButton(
                                onPressed: () {
                                  Navigator.push(
                                    context, MaterialPageRoute(builder: (context) => const PetAdoptionForm(),
                                    ),
                                  );
                                },
                                style: TextButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 6.0, horizontal: 10.0),
                                  backgroundColor: Colors.green.withOpacity(0.2), shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: const Text(
                                  'Adopt Now',
                                  style: TextStyle(
                                      color: Colors.green, fontSize: 12, fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
