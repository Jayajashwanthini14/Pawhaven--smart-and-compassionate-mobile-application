import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../databasehelper/db_rescueregis.dart';
import '../viewscreens/needsupport.dart';


class ViewRescueSheltersPage extends StatefulWidget {
  const ViewRescueSheltersPage({super.key});

  @override
  _ViewRescueSheltersPageState createState() => _ViewRescueSheltersPageState();
}

class _ViewRescueSheltersPageState extends State<ViewRescueSheltersPage> {
  List<Map<String, dynamic>> _shelters = [];

  @override
  void initState() {
    super.initState();
    _loadShelters();
  }

  Future<void> _loadShelters() async {
    List<Map<String, dynamic>> shelters = await DatabaseHelper().getShelters();
    setState(() {
      _shelters = shelters;
    });
  }

  void _callShelter(String phoneNumber) async {
    final Uri callUri = Uri.parse("tel:$phoneNumber");
    if (await canLaunchUrl(callUri)) {
      await launchUrl(callUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not launch dialer")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rescue Shelters'),
        backgroundColor: Colors.orangeAccent,
        centerTitle: true,
        elevation: 5,
      ),
      body: _shelters.isEmpty
          ? const Center(
        child: Text('No rescue shelters available.',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: _shelters.length,
        itemBuilder: (context, index) {
          final shelter = _shelters[index];
          return Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
            ),
            elevation: 6,
            shadowColor: Colors.black26,
            margin: const EdgeInsets.symmetric(vertical: 10),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    shelter['name'], style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                    ),
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.location_on, size: 20, color: Colors.redAccent),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          shelter['location'], style: const TextStyle(fontSize: 16),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.pets, size: 20, color: Colors.teal),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Animals: ${shelter['animal_types']}', style: const TextStyle(fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Slots Available: ${(shelter['max_capacity'] - shelter['current_occupancy'])}',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,
                      color: (shelter['max_capacity'] - shelter['current_occupancy']) > 0
                          ? Colors.green
                          : Colors.red,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.info, size: 20),
                          label: const Text('Details'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.orange,
                            side: const BorderSide(color: Colors.orange),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context, MaterialPageRoute(
                                builder: (context) => RescueShelterDetailsPage(shelter: shelter),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.volunteer_activism, size: 20),
                          label: const Text('Support'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.blueAccent,
                            side: const BorderSide(color: Colors.blueAccent),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context, MaterialPageRoute(
                                builder: (context) => const ShelterSupport(),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.call, size: 20, color: Colors.white),
                          label: const Text('Call'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onPressed: () => _callShelter(shelter['phone']),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class RescueShelterDetailsPage extends StatelessWidget {
  final Map<String, dynamic> shelter;

  const RescueShelterDetailsPage({super.key, required this.shelter});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rescue Shelter Details'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Card(
          margin: const EdgeInsets.all(8.0),
          elevation: 5,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Shelter Name', shelter['name'], Icons.pets),
                _buildDetailRow('Location', shelter['location'], Icons.location_on),
                _buildDetailRow('Phone', shelter['phone'], Icons.phone),
                _buildDetailRow('Email', shelter['email'], Icons.email),
                _buildDetailRow('Animal Types', shelter['animal_types'], Icons.category),
                _buildDetailRow('Max Capacity', shelter['max_capacity'].toString(), Icons.people),
                _buildDetailRow('Current Occupancy', shelter['current_occupancy'].toString(), Icons.person_outlined),
                _buildDetailRow('Available Slots', (shelter['max_capacity'] - shelter['current_occupancy']).toString(),
                  Icons.check_circle_outline, valueColor: Colors.green,
                ),
                _buildDetailRow('Description', shelter['description'], Icons.description),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(
      String title, String value,
      IconData icon, {
        Color? valueColor,
      }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 24, color: Colors.orangeAccent),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title, style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold,
                ),
                ),
                const SizedBox(height: 4),
                Text(
                  value, style: TextStyle(
                  // fontSize: 12,color: valueColor ?? Colors.black,
                  fontSize: 15,color: valueColor ?? Colors.black87,
                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}