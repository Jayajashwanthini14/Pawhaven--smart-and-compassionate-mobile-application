// import 'dart:io';
// import 'package:flutter/material.dart';
// import '../../databasehelper/db_helper.dart';
// import '../viewscreens/adoptionform.dart';
//
// class Detailshere extends StatelessWidget {
//   final Map<String, dynamic> animal;
//
//   const Detailshere({super.key, required this.animal});
//
//   @override
//   Widget build(BuildContext context) {
//     final imagePath = animal['imagePath'];
//     final animalType = animal['animalType']?.toLowerCase() ?? '';
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Animal Details'),
//         backgroundColor: Colors.pinkAccent,
//         elevation: 0,
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//           child: Card(
//             elevation: 12,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(16),
//             ),
//             clipBehavior: Clip.antiAlias,
//             child: Column(
//               children: [
//                 _buildImageSection(imagePath),
//                 const SizedBox(height: 16),
//
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 16.0),
//                   child: Text(
//                     animal['title'] ?? 'Unnamed Animal',
//                     style: const TextStyle(
//                       fontWeight: FontWeight.bold, fontSize: 28, color: Colors.black87,
//                     ),
//                     textAlign: TextAlign.center,
//                   ),
//                 ),
//                 const SizedBox(height: 8),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 16.0),
//                   child: Text(
//                     'Type: ${animal['animalType']}',
//                     style: const TextStyle(fontSize: 18, color: Colors.grey,
//                     ),
//                     textAlign: TextAlign.center,
//                   ),
//                 ),
//
//                 const SizedBox(height: 16),
//                 if (animalType == 'stray' || animalType == 'pet') ...[
//                   _buildAnimalDetailWithIcon(Icons.pets, 'Breed', animal['breed']),
//                   _buildAnimalDetailWithIcon(
//                       Icons.location_on, 'Location', animal['location']),
//                   _buildAnimalDetailWithIcon(Icons.height, 'Size', animal['size']),
//                   _buildAnimalDetailWithIcon(
//                       Icons.male_outlined, 'Gender', animal['gender']),
//                 ],
//
//                 if (animalType != 'stray')
//                   _buildAnimalDetailWithIcon(
//                     Icons.attach_money,
//                     'Price', animal['price'] != null
//                         ? '\$${animal['price']}'
//                         : 'Not specified',
//                     iconColor: animal['price'] != null ? Colors.green : Colors.redAccent,
//                   ),
//
//                 if (animalType != 'stray')
//                   _buildAnimalDetailWithIcon(
//                     Icons.question_mark, 'Reason for Adoption',
//                     animal['reason'] ?? 'No reason provided',
//                     iconColor: Colors.redAccent,
//                   ),
//
//                 _buildAnimalDetailWithIcon(
//                   Icons.description, 'Description',
//                   animal['description'] ?? 'No description available.',
//                   iconColor: Colors.blue,
//                 ),
//
//                 const SizedBox(height: 24),
//                 Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 40.0),
//                   child: ElevatedButton(
//                     onPressed: () {
//                       Navigator.push(context, MaterialPageRoute(
//                           builder: (context) => const PetAdoptionForm(),
//                         ),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       backgroundColor: Colors.green,
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                     ),
//                     child: const Text(
//                       'Adopt Now',
//                       style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white,
//                       ),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 16),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildImageSection(String? imagePath) {
//     return imagePath != null && File(imagePath).existsSync()
//         ? ClipRRect(
//       borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
//       child: Image.file(
//         File(imagePath),
//         width: double.infinity, height: 280, fit: BoxFit.cover,
//       ),
//     )
//         : ClipRRect(
//       borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
//       child: Container(
//         color: Colors.grey[300],
//         height: 280, child: const Icon(
//           Icons.image, size: 100, color: Colors.grey,
//         ),
//       ),
//     );
//   }
//
//   Widget _buildAnimalDetailWithIcon(
//       IconData icon, String label, String? value,
//       {Color iconColor = Colors.pinkAccent}) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Icon(icon, color: iconColor, size: 20),
//           const SizedBox(width: 8),
//           Text(
//             '$label: ',
//             style: const TextStyle(
//               fontWeight: FontWeight.bold,
//               fontSize: 16, color: Colors.black87,
//             ),
//           ),
//           Expanded(
//             child: Text(
//               value ?? 'Not specified',
//               style: const TextStyle(
//                 fontSize: 16, color: Colors.black54,
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'dart:io';
import 'package:flutter/material.dart';
import '../viewscreens/adoptionform.dart';
import 'Accessories.dart';


class Detailshere extends StatelessWidget {
  final Map<String, dynamic> animal;

  const Detailshere({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    final imagePath = animal['imagePath'];
    final animalType = animal['animalType']?.toLowerCase() ?? 'unknown';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Animal Details'),
        backgroundColor: Colors.pinkAccent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Card(
            elevation: 12,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              children: [
                _buildImageSection(imagePath),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text(
                    animal['animalType'] == 'Accessory'
                        ? animal['productName'] ?? 'Unnamed Product'
                        : animal['title'] ?? 'Unnamed Animal',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Text(
                    'Type: ${animal['animalType']}',
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 16),
                if (animalType == 'stray' || animalType == 'pet') ...[
                  _buildAnimalDetailWithIcon(Icons.pets, 'Breed', animal['breed'] ?? 'Unknown Breed'),
                  _buildAnimalDetailWithIcon(Icons.location_on, 'Location', animal['location'] ?? 'Not specified'),
                  _buildAnimalDetailWithIcon(Icons.height, 'Size', animal['size'] ?? 'Not specified'),
                  _buildAnimalDetailWithIcon(Icons.male_outlined, 'Gender', animal['gender'] ?? 'Not specified'),
                ],
                if (animalType != 'stray')
                  _buildAnimalDetailWithIcon(
                    Icons.attach_money,
                    'Price',
                    animal['price'] != null ? '\$${animal['price']}' : 'Not specified',
                    iconColor: animal['price'] != null ? Colors.green : Colors.redAccent,
                  ),
                if (animalType == 'pet')
                  _buildAnimalDetailWithIcon(
                    Icons.question_mark,
                    'Reason for Adoption',
                    animal['reason'] ?? 'No reason provided',
                    iconColor: Colors.redAccent,
                  ),
                if (animalType == 'accessory')
                  _buildAnimalDetailWithIcon(
                    Icons.timer_outlined,
                    'Years Used', animal['yearsUsed']?.toString() ?? 'Not specified',
                    iconColor: Colors.green,
                  ),
                _buildAnimalDetailWithIcon(
                  Icons.description,
                  'Description',
                  animal['description'] ?? 'No description available.',
                  iconColor: Colors.blue,
                ),
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: ElevatedButton(
                    onPressed: () {
                      if (animalType == 'accessory') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AccessoryDetailsPage(
                              accessory: animal,
                            ),
                          ),
                        );
                      } else {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const PetAdoptionForm(),
                          ),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: animalType == 'accessory' ? Colors.blue : Colors.green,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      animalType == 'accessory' ? 'Buy Now' : 'Adopt Now',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildImageSection(String? imagePath) {
    if (imagePath != null && File(imagePath).existsSync()) {
      return ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: Image.file(
          File(imagePath),
          width: double.infinity,
          height: 280, fit: BoxFit.cover,
        ),
      );
    } else {
      return ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
        child: Container(
          color: Colors.grey[300],
          height: 280,
          child: const Icon(
            Icons.image, size: 100, color: Colors.grey,
          ),
        ),
      );
    }
  }

  Widget _buildAnimalDetailWithIcon(IconData icon, String label, String? value,
      {Color iconColor = Colors.pinkAccent}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: iconColor, size: 20),
          const SizedBox(width: 8),
          Text(
            '$label: ',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          Expanded(
            child: Text(
              value ?? 'Not specified',
              style: const TextStyle(
                fontSize: 16,
                color: Colors.black54,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
