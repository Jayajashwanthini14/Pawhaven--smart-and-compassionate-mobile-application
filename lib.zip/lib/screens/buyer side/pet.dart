import 'package:flutter/material.dart';
import 'dart:io';

import '../../databasehelper/db_helper.dart';
import '../viewscreens/adoptionform.dart';


class PetPage extends StatelessWidget {
  final bool showAppBar;

  const PetPage({super.key, this.showAppBar = true });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adopt Me'),
        backgroundColor: Colors.white54,
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.favorite),
        //     onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => const FavoritesPage()),
        //       );
        //     },
        //   ),
        // ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DatabaseHelper.instance.fetchAnimalsByType('Pet'),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No pets available.'));
          }

          final pets = snapshot.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: pets.length,
            itemBuilder: (context, index) {
              return PetCard(pet: pets[index]);
            },
          );
        },
      ),
    );
  }
}

class PetCard extends StatelessWidget {
  final Map<String, dynamic> pet;

  const PetCard({super.key, required this.pet});

  @override
  Widget build(BuildContext context) {
    final isFavorite = pet['isFavorite'] == 1;

    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => PetDetailPage(pet: pet),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            _buildPetImage(pet['imagePath']),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pet['title'] ?? 'Unnamed Pet', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      pet['description'] ?? 'No description available',
                      style: const TextStyle(fontSize: 14, color: Colors.black54,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      pet['price'] != null
                          ? '₹${pet['price']}'
                          : 'Price: Not specified',
                      style: const TextStyle(fontSize: 14, color: Colors.green, fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _navigateToAdoptionForm(context),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.pinkAccent, shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Adopt Now', style: TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => _toggleFavoriteStatus(context, isFavorite),
                          icon: Icon(
                            isFavorite ? Icons.favorite : Icons.favorite_border,
                            color: Colors.redAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPetImage(String? imagePath) {
    return ClipRRect(
      borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
      child: imagePath != null && File(imagePath).existsSync()
          ? Image.file(
        File(imagePath), width: 120, height: 120, fit: BoxFit.cover,
      )
          : Container(
        width: 120, height: 120, color: Colors.grey,
        child: const Icon(Icons.pets, size: 60, color: Colors.white),
      ),
    );
  }

  void _navigateToAdoptionForm(BuildContext context) {
    Navigator.push(
      context, MaterialPageRoute(builder: (context) => const PetAdoptionForm()),
    );
  }

  Future<void> _toggleFavoriteStatus(BuildContext context, bool isFavorite) async {
    final newStatus = !isFavorite;
    await DatabaseHelper.instance.updateFavoriteStatus(pet['id'], newStatus);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(newStatus
            ? '${pet['title']} added to favorites!'
            : '${pet['title']} removed from favorites!'),
      ),
    );
  }
}


class PetDetailPage extends StatefulWidget {
  final Map<String, dynamic> pet;

  const PetDetailPage({super.key, required this.pet});

  @override
  _PetDetailPageState createState() => _PetDetailPageState();
}

class _PetDetailPageState extends State<PetDetailPage> {
  late bool isFavorite;

  @override
  void initState() {
    super.initState();
    isFavorite = widget.pet['isFavorite'] == 1;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.pet['title'] ?? 'Pet Details',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        foregroundColor: Colors.pinkAccent,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: widget.pet['imagePath'] != null && File(widget.pet['imagePath']).existsSync()
                  ? ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(widget.pet['imagePath']),
                  width: double.infinity, height: 300, fit: BoxFit.cover,
                ),
              )
                  : Container(
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.grey.shade200,
                ),
                child: const Icon(
                  Icons.pets, size: 100, color: Colors.grey,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.pet['title'] ?? 'Unnamed Pet',
                  style: const TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black,
                  ),
                ),
                Text(
                  widget.pet['price'] != null ? '\$${widget.pet['price']}' : 'Not specified',
                  style: const TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold, color: Colors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            const Text('Pet Details',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w400, color: Colors.indigo),
            ),
            const SizedBox(height: 8),
            Text(
              widget.pet['description'] ?? 'No description available',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 8),
            _buildDetailRow('Breed', widget.pet['breed'] ?? 'Unknown'),
            _buildDetailRow('Type', widget.pet['type'] ?? 'Unknown'),
            _buildDetailRow('Size', widget.pet['size'] ?? 'Unknown'),
            _buildDetailRow('Gender', widget.pet['gender'] ?? 'Unknown'),
            _buildDetailRow('Location', widget.pet['location'] ?? 'Unknown'),
            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context, MaterialPageRoute(
                          builder: (context) => const PetAdoptionForm(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.pinkAccent,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Adopt Now',
                      style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                ElevatedButton(
                  onPressed: () async {
                    setState(() {
                      isFavorite = !isFavorite;
                    });
                    await DatabaseHelper.instance.updateFavoriteStatus(widget.pet['id'], isFavorite);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          isFavorite
                              ? '${widget.pet['title']} added to favorites!'
                              : '${widget.pet['title']} removed from favorites!',
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Icon(
                    isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: Colors.white, size: 24,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ', style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16,
            ),
          ),
          Expanded(
            child: Text(
              value, style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}
