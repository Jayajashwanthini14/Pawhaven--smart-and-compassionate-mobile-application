import 'package:flutter/material.dart';
import 'dart:io';

import '../../databasehelper/db_helper.dart';
import '../viewscreens/adoptionform.dart';
import '../viewscreens/favoritespage.dart';

class StrayPage extends StatelessWidget {
  final bool showAppBar;

  const StrayPage({super.key, this.showAppBar = true });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adopt Me'),
        backgroundColor: Colors.white54,
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => const FavoritesPage()),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DatabaseHelper.instance.fetchAnimalsByType('Stray'),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No stray animals available.'));
          }

          final strays = snapshot.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: strays.length, itemBuilder: (context, index) {
              return StrayCard(stray: strays[index]);
            },
          );
        },
      ),
    );
  }
}

class StrayCard extends StatelessWidget {
  final Map<String, dynamic> stray;

  const StrayCard({super.key, required this.stray});

  @override
  Widget build(BuildContext context) {
    final isFavorite = stray['isFavorite'] == 1;

    return GestureDetector(
      onTap: () {
        Navigator.push(context,
          MaterialPageRoute(builder: (context) => StrayDetailPage(stray: stray),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            _buildStrayImage(stray['imagePath']),
            Expanded(
               child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      stray['title'] ?? 'Unnamed Stray Animal',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16,
                      ),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      stray['description'] ?? 'No description available',
                      style: const TextStyle(
                        fontSize: 14, color: Colors.black54,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _navigateToAdoptionForm(context),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.cyan,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Adopt Now',style: TextStyle(fontSize: 12),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => _toggleFavoriteStatus(context, isFavorite),
                          icon: Icon(
                            isFavorite ? Icons.favorite : Icons.favorite_border,
                            color: Colors.redAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStrayImage(String? imagePath) {
    return ClipRRect(
      borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
      child: imagePath != null && File(imagePath).existsSync()
          ? Image.file(
        File(imagePath),
        width: 120, height: 120, fit: BoxFit.cover,
      )
          : Container(
        width: 120, height: 120, color: Colors.grey,
        child: const Icon(Icons.pets, size: 60, color: Colors.white),
      ),
    );
  }

  void _navigateToAdoptionForm(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => const PetAdoptionForm()),
    );
  }

  Future<void> _toggleFavoriteStatus(BuildContext context, bool isFavorite) async {
    final newStatus = !isFavorite;
    await DatabaseHelper.instance.updateFavoriteStatus(stray['id'], newStatus);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(newStatus
            ? '${stray['title']} added to favorites!'
            : '${stray['title']} removed from favorites!'),
      ),
    );
  }
}



class StrayDetailPage extends StatefulWidget {
  final Map<String, dynamic> stray;

  const StrayDetailPage({super.key, required this.stray});

  @override
  _StrayDetailPageState createState() => _StrayDetailPageState();
}

class _StrayDetailPageState extends State<StrayDetailPage> {
  late bool isFavorite;

  @override
  void initState() {
    super.initState();
    isFavorite = widget.stray['isFavorite'] == 1;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.stray['title'] ?? 'Stray Animal Details',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.cyan,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStrayImage(widget.stray['imagePath']),
            const SizedBox(height: 20),
            Text(
              widget.stray['title'] ?? 'Unnamed Stray Animal',
              style: const TextStyle(
                fontSize: 24, fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              widget.stray['description'] ?? 'No description available',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),

            _buildDetailRow('Breed', widget.stray['breed'] ?? 'Unknown'),
            _buildDetailRow('Type', widget.stray['type'] ?? 'Unknown'),
            _buildDetailRow('Size', widget.stray['size'] ?? 'Unknown'),
            _buildDetailRow('Gender', widget.stray['gender'] ?? 'Unknown'),
            _buildDetailRow('Location', widget.stray['location'] ?? 'Unknown'),
            const SizedBox(height: 16),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context, MaterialPageRoute(
                          builder: (context) => const PetAdoptionForm(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.cyan,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      'Adopt Now',
                      style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                ElevatedButton(
                  onPressed: () async {
                    setState(() {
                      isFavorite = !isFavorite;
                    });
                    await DatabaseHelper.instance.updateFavoriteStatus(widget.stray['id'], isFavorite);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          isFavorite
                              ? '${widget.stray['title']} added to favorites!'
                              : '${widget.stray['title']} removed from favorites!',
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Icon(
                    isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    color: Colors.white, size: 24,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStrayImage(String? imagePath) {
    return imagePath != null && File(imagePath).existsSync()
        ? ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.file(
        File(imagePath),
        width: double.infinity, height: 250, fit: BoxFit.cover,
      ),
    )
        : Container(
      height: 250, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.grey.shade200,
      ),
      child: const Icon(
        Icons.pets, size: 100, color: Colors.grey,
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}
