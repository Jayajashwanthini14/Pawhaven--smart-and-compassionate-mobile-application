import 'package:url_launcher/url_launcher.dart';

Future<void> dialNumber(String phoneNumber) async {
  final Uri launchUri = Uri(
    scheme: 'tel',
    path: phoneNumber,
  );
  if (await canLaunch(launchUri.toString())) {
    await launch(launchUri.toString());
  } else {
    throw 'Could not dial $phoneNumber';
  }
}

// // Function to handle opening website
// Future<void> openWebsite(String websiteUrl) async {
//   final Uri url = Uri.parse(websiteUrl);
//   if (await canLaunch(url.toString())) {
//     await launch(url.toString());
//   } else {
//     throw 'Could not open the website';
//   }
// }