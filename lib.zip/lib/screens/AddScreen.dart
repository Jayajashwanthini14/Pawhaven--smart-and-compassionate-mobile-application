import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:untitled4/databasehelper/db_helper.dart';
import 'package:untitled4/screens/viewscreens/allanimalsview.dart';



void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.pinkAccent,
        scaffoldBackgroundColor: Colors.grey[100],
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.black87),
          bodyMedium: TextStyle(color: Colors.black54),
        ),
        buttonTheme: const ButtonThemeData(buttonColor: Colors.pinkAccent),
      ),
      home: const AnimalTypeSelection(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AnimalTypeSelection extends StatelessWidget {
  const AnimalTypeSelection({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pass the Paw Forward',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.pinkAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            tooltip: 'View Stored Animals',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const StoredAnimalsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _buildAnimalOption(context, 'assets/images/Pet.jpg', 'Pet', 'Rehome Your Pet', const GalleryAccess(animalType: '',)),
            _buildAnimalOption(context, 'assets/images/Stray.jpg', 'Stray', 'Find a New Home for Stray', const GalleryAccess(animalType: '',)),
            _buildAnimalOption(context, 'assets/images/Access.jpg', 'Accessory', 'Sell your reusable pet accessories', const GalleryAccess(animalType: '',)),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimalOption(
      BuildContext context, String imagePath, String type, String description, Widget navigateToPage) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => navigateToPage),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 4,
        shadowColor: Colors.black.withOpacity(0.2),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  imagePath,
                  height: 80,
                  width: 80,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      type,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.pinkAccent,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}





class GalleryAccess extends StatefulWidget {
  final String animalType;

  const GalleryAccess({super.key, required this.animalType});

  @override
  State<GalleryAccess> createState() => _GalleryAccessState();
}

class _GalleryAccessState extends State<GalleryAccess> {
  List<File> galleryFiles = [];
  final picker = ImagePicker();

  final _formKey = GlobalKey<FormState>();

  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final priceController = TextEditingController();
  final reasonController = TextEditingController();
  final productNameController = TextEditingController();
  final yearsUsedController = TextEditingController();
  final genderController = TextEditingController();
  final sizeController = TextEditingController();
  final breedController = TextEditingController();
  final locationController = TextEditingController();

  List<String> yearsOptions = ['less than 1', '1', '2', '3', '4', '5', 'More than 5'];
  List<String> genderOptions = ['Male', 'Female'];
  List<String> sizeOptions = ['Small', 'Medium', 'Large'];

  Future<void> _selectImages() async {
    final pickedFiles = await picker.pickMultiImage();
    if (pickedFiles.isNotEmpty) {
      setState(() {
        for (var file in pickedFiles) {
          galleryFiles.add(File(file.path));
        }
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No images selected')),
      );
    }
  }

  Widget _buildTextField(String label, TextEditingController controller,
      {int maxLines = 1, TextInputType keyboardType = TextInputType.text, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      maxLines: maxLines,
      keyboardType: keyboardType,
      validator: validator,
    );
  }

  Widget _buildDropdown(String label, List<String> options,
      TextEditingController controller, String? Function(String?)? validator) {
    return DropdownButtonFormField<String>(
      value: controller.text.isEmpty ? null : controller.text,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      onChanged: (value) {
        setState(() {
          controller.text = value!;
        });
      },
      validator: validator,
      items: options.map((String option) {
        return DropdownMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Details'),
        backgroundColor: Colors.pinkAccent,
      ),
      backgroundColor: Colors.lightBlue[50],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                Text(
                  'Animal Type: ${widget.animalType}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _selectImages,
                  child: const Text('Select Images'),
                ),
                const SizedBox(height: 20),
                galleryFiles.isNotEmpty
                    ? ListView.builder(
                  shrinkWrap: true,
                  itemCount: galleryFiles.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8.0),
                      child: Image.file(
                        galleryFiles[index],
                        height: 200, width: double.infinity, fit: BoxFit.cover,
                      ),
                    );
                  },
                )
                    : const Text('No images selected'),
                const SizedBox(height: 20),
                if (widget.animalType == 'Accessory') ...[
                  _buildTextField(
                    'Product Name', productNameController,
                    validator: (value) => value == null || value.isEmpty ? 'Product name is required' : null,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    'Price',
                    priceController,
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) return 'Price is required';
                      if (double.tryParse(value) == null) return 'Enter a valid number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 10),
                  _buildDropdown('Years Used', yearsOptions, yearsUsedController,
                          (value) => value == null || value.isEmpty ? 'Select an option' : null),
                  const SizedBox(height: 10),
                  _buildTextField(
                    'Description',
                    descriptionController,
                    maxLines: 3,
                    validator: (value) => value == null || value.isEmpty ? 'Description is required' : null,
                  ),
                ] else ...[
                  _buildTextField(
                    'Animal Title', titleController,
                    validator: (value) => value == null || value.isEmpty ? 'Title is required' : null,
                  ),
                  const SizedBox(height: 10),
                  _buildTextField(
                    'Animal Description', descriptionController,
                    maxLines: 3,
                    validator: (value) => value == null || value.isEmpty ? 'Description is required' : null,
                  ),
                  const SizedBox(height: 10),
                  _buildDropdown('Gender', genderOptions, genderController,
                          (value) => value == null || value.isEmpty ? 'Select an option' : null),
                  const SizedBox(height: 10),
                  _buildDropdown('Size', sizeOptions, sizeController,
                          (value) => value == null || value.isEmpty ? 'Select an option' : null),
                  const SizedBox(height: 10),
                  _buildTextField('Breed', breedController,
                      validator: (value) => value == null || value.isEmpty ? 'Breed is required' : null),
                  const SizedBox(height: 10),
                  _buildTextField('Location', locationController,
                      validator: (value) => value == null || value.isEmpty ? 'Location is required' : null),
                  const SizedBox(height: 10),
                  if (widget.animalType != 'Stray') ...[
                    _buildTextField(
                      'Price', priceController,
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) return 'Price is required';
                        if (double.tryParse(value) == null) return 'Enter a valid number';
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    _buildTextField(
                      'Reason for Giving Away',
                      reasonController,
                      maxLines: 3,
                      validator: (value) => value == null || value.isEmpty ? 'Reason is required' : null,
                    ),
                  ],
                ],
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      final animalDetails = {
                        'animalType': widget.animalType,
                        'title': titleController.text,
                        'description': descriptionController.text,
                        'gender': widget.animalType != 'Accessory' ? genderController.text : null,
                        'size': widget.animalType != 'Accessory' ? sizeController.text : null,
                        'breed': widget.animalType != 'Accessory' ? breedController.text : null,
                        'location': widget.animalType != 'Accessory' ? locationController.text : null,
                        'price': priceController.text.isNotEmpty ? priceController.text : null,
                        'reason': reasonController.text.isNotEmpty ? reasonController.text : null,
                        'productName': widget.animalType == 'Accessory' ? productNameController.text : null,
                        'yearsUsed': widget.animalType == 'Accessory' ? yearsUsedController.text : null,
                      };

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PreviewScreen(
                            animalDetails: animalDetails,
                            galleryFiles: galleryFiles,
                          ),
                        ),
                      );
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Please fill all required fields')),
                      );
                    }
                  },
                  child: const Text('Preview Details'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PreviewScreen extends StatelessWidget {
  final Map<String, dynamic> animalDetails;
  final List<File> galleryFiles;

  const PreviewScreen({
    super.key,
    required this.animalDetails,
    required this.galleryFiles,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Preview Details'),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDetailRow('Animal Type:', animalDetails['animalType'] ?? 'Unknown'),
                      const SizedBox(height: 10),
                      _buildDetailRow('Title:', animalDetails['title'] ?? 'No Title'),

                      const SizedBox(height: 10),
                      _buildDetailRow('Description:', animalDetails['description'] ?? 'No Description'),
                      if (animalDetails['gender'] != null) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Gender:', animalDetails['gender']),
                      ],
                      if (animalDetails['size'] != null) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Size:', animalDetails['size']),
                      ],
                      if (animalDetails['breed'] != null) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Breed:', animalDetails['breed']),
                      ],
                      if (animalDetails['location'] != null) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Location:', animalDetails['location']),
                      ],
                      if (animalDetails['price'] != null) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Price:', '\$${animalDetails['price']}'),
                      ],
                      if (animalDetails['reason'] != null && animalDetails['reason']!.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        _buildDetailRow('Reason for Giving Away:', animalDetails['reason']),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Selected Images:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              galleryFiles.isNotEmpty
                  ? GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 10,
                  mainAxisSpacing: 10, childAspectRatio: 1,
                ),
                itemCount: galleryFiles.length,
                itemBuilder: (context, index) {
                  return ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(
                      galleryFiles[index], fit: BoxFit.cover,
                    ),
                  );
                },
              )
                  : const Text('No images selected',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueGrey,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    ),
                    child: const Text('Edit'),
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      try {
                        final animalDetailsToSave = {
                          'animalType': animalDetails['animalType'] ?? 'Unknown',
                          'type': animalDetails['animalType'] ?? 'Unknown',
                          'title': animalDetails['title'] ?? 'No Title',
                          'description': animalDetails['description'] ?? 'No Description',
                          'gender': animalDetails['gender'] ?? '',
                          'size': animalDetails['size'] ?? '',
                          'breed': animalDetails['breed'] ?? '',
                          'location': animalDetails['location'] ?? '',
                          'price': animalDetails['price'] ?? '0',
                          'reason': animalDetails['reason'] ?? '',
                          'productName': animalDetails['productName'] ?? '',
                          'yearsUsed': animalDetails['yearsUsed'] ?? 0,
                          'imagePath': galleryFiles.isNotEmpty ? galleryFiles.first.path : '',
                          'favorite': 0,
                        };

                        await DatabaseHelper.instance.insertAnimal(animalDetailsToSave);

                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Details saved!')),
                        );

                        Navigator.pushAndRemoveUntil(
                          context, MaterialPageRoute(builder: (context) => const StoredAnimalsScreen()),
                              (route) => false,
                        );
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Error saving details')),
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    ),
                    child: const Text('Save'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value, style: const TextStyle(fontSize: 16),
          ),
        ),
      ],
    );
  }
}







//
// class StoredAnimalsScreen extends StatelessWidget {
//   const StoredAnimalsScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Stored Animal Details'),
//         backgroundColor: Colors.pinkAccent,
//       ),
//       body: FutureBuilder<List<Map<String, dynamic>>>(
//         future: DatabaseHelper.instance.fetchAnimals(),
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
//             return const Center(child: Text('No animals stored yet.'));
//           } else {
//             final animals = snapshot.data!;
//             return ListView.builder(
//               padding: const EdgeInsets.all(16.0),
//               itemCount: animals.length,
//               itemBuilder: (context, index) {
//                 final animal = animals[index];
//                 final imagePath = animal['imagePath'];
//
//                 return Card(
//                   elevation: 8,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   margin: const EdgeInsets.symmetric(vertical: 8.0),
//                   child: ListTile(
//                     contentPadding: const EdgeInsets.all(12.0),
//                     leading: imagePath != null && File(imagePath).existsSync()
//                         ? ClipRRect(
//                       borderRadius: BorderRadius.circular(8),
//                       child: Image.file(
//                         File(imagePath), // Display image from file
//                         width: 80,
//                         height: 80,
//                         fit: BoxFit.cover,
//                       ),
//                     )
//                         : ClipRRect(
//                       borderRadius: BorderRadius.circular(8),
//                       child: const Icon(
//                         Icons.image,
//                         size: 60,
//                         color: Colors.grey,
//                       ),
//                     ), // Fallback icon if image is null or invalid
//                     title: Text(
//                       animal['title'] ?? 'Unnamed Animal',
//                       style: const TextStyle(
//                         fontWeight: FontWeight.bold,
//                         fontSize: 16,
//                       ),
//                     ),
//                     subtitle: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           'Type: ${animal['animalType']}',
//                           style: const TextStyle(
//                             fontSize: 14,
//                             color: Colors.grey,
//                           ),
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           'Price: ${animal['price']}',
//                           style: const TextStyle(
//                             fontSize: 14,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           'Reason: ${animal['reason']}',
//                           style: const TextStyle(
//                             fontSize: 14,
//                             color: Colors.redAccent,
//                           ),
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           'Description: ${animal['description']}',
//                           style: const TextStyle(
//                             fontSize: 12,
//                             color: Colors.black54,
//                           ),
//                           maxLines: 2,
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                       ],
//                     ),
//                     isThreeLine: true,
//                     trailing: IconButton(
//                       icon: const Icon(
//                         Icons.arrow_forward_ios,
//                         color: Colors.pinkAccent,
//                       ),
//                       onPressed: () {
//                         // Navigate to the detailed screen
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(
//                             builder: (context) => AnimalDetailScreen(animal: animal),
//                           ),
//                         );
//                       },
//                     ),
//                   ),
//                 );
//               },
//             );
//           }
//         },
//       ),
//     );
//   }
// }
//
//
//
// class AnimalDetailScreen extends StatelessWidget {
//   final Map<String, dynamic> animal;
//
//   const AnimalDetailScreen({super.key, required this.animal});
//
//   @override
//   Widget build(BuildContext context) {
//     final imagePath = animal['imagePath'];
//
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Animal Details'),
//         backgroundColor: Colors.pinkAccent,
//       ),
//       body: SingleChildScrollView( // Makes the content scrollable if it exceeds the screen size
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Card(
//             elevation: 8,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   // Image Display
//                   imagePath != null && File(imagePath).existsSync()
//                       ? ClipRRect(
//                     borderRadius: BorderRadius.circular(8),
//                     child: Image.file(
//                       File(imagePath), // Display image from file
//                       width: double.infinity,
//                       height: 250, // Adjust height to take up more space
//                       fit: BoxFit.cover,
//                     ),
//                   )
//                       : ClipRRect(
//                     borderRadius: BorderRadius.circular(8),
//                     child: const Icon(
//                       Icons.image,
//                       size: 250,
//                       color: Colors.grey,
//                     ),
//                   ),
//
//                   const SizedBox(height: 16),
//
//                   // Title
//                   Text(
//                     animal['title'] ?? 'Unnamed Animal',
//                     style: const TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 24,const SizedBox(height: 8),
//                     ),
//                   ),
//
//
//                   // Animal Type
//                   Text(
//                     'Type: ${animal['animalType']}',
//                     style: const TextStyle(
//                       fontSize: 18,
//                       color: Colors.grey,
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//
//                   // Price
//                   Text(
//                     'Price: ${animal['price']}',
//                     style: const TextStyle(
//                       fontSize: 18, fontWeight: FontWeight.bold,
//
//                     ),
//                   ),
//                   const SizedBox(height: 8),
//
//                   // Reason
//                   Text(
//                     'Reason: ${animal['reason']}',
//                     style: const TextStyle(
//                       fontSize: 18, color: Colors.redAccent,
//
//                     ),
//                   ),
//                   const SizedBox(height: 16),
//
//                   // Description
//                   Text(
//                     'Description: ${animal['description']}',
//                     style: const TextStyle(
//                       fontSize: 16,color: Colors.black87,
//
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
