import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Settings App',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SettingsScreen(),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = false;
  bool _darkModeEnabled = false;
  String _username = 'full_name';
  bool _receiveEmails = false;
  bool _hasHelpAccess = false;
  final String _appVersion = "1.0.0";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orangeAccent,
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5, blurRadius: 7,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Settings', style: TextStyle(fontSize: 32,
                    ),
                  ),
                  const SizedBox(height: 20),

                  _buildCard(
                    child: ListTile(
                      title: const Text('full_name'), subtitle: Text(_username),
                      onTap: () async {
                        String? newUsername = await _showUsernameDialog();
                        if (newUsername != null && newUsername.isNotEmpty) {
                          setState(() {
                            _username = newUsername;
                          });
                        }
                      },
                    ),
                  ),
                  const SizedBox(height: 15),

                  _buildCard(
                    child: SwitchListTile(
                      title: const Text('Enable Notifications'),
                      value: _notificationsEnabled, onChanged: (bool value) {
                        setState(() {
                          _notificationsEnabled = value;
                        });
                      },
                    ),
                  ),
                  const SizedBox(height: 15),

                  _buildCard(
                    child: SwitchListTile(
                      title: const Text('Dark Mode'),
                      value: _darkModeEnabled,
                      onChanged: (bool value) {
                        setState(() {
                          _darkModeEnabled = value;
                        });
                      },
                    ),
                  ),
                  const SizedBox(height: 15),

                  _buildCard(
                    child: ListTile(
                      title: const Text('Email Preferences'),
                      subtitle: Text(_receiveEmails ? "Enabled" : "Disabled"),
                      trailing: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _receiveEmails = !_receiveEmails;
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                          backgroundColor: Colors.orangeAccent,
                        ),
                        child: Text(_receiveEmails ? "Disable" : "Enable"),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  _buildCard(
                    child: ListTile(
                      title: const Text('Help'),
                      subtitle: Text(_hasHelpAccess ? "Access Enabled" : "Access Disabled"),
                      trailing: ElevatedButton(
                        onPressed: () {
                          _showHelpDialog();
                        }, style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                          backgroundColor: Colors.orangeAccent,
                        ),
                        child: const Text("Open Help"),
                      ),
                    ),
                  ),
                  const SizedBox(height: 15),

                  _buildCard(
                    child: ListTile(
                      title: const Text('App Version'),
                      subtitle: Text(_appVersion),
                    ),
                  ),
                  const SizedBox(height: 20),

                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(12.0),
                      child: ElevatedButton(
                        onPressed: () {
                          _showResetDialog();
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          backgroundColor: Colors.white,
                          elevation: 1,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                        ),
                        child: const Text(
                          'Reset Settings',
                          style: TextStyle(fontSize: 18, color: Colors.black),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      margin: const EdgeInsets.all(8.0),
      child: child,
    );
  }

  Future<String?> _showUsernameDialog() async {
    TextEditingController controller = TextEditingController(text: _username);
    return showDialog<String>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Change Username'),
          content: TextField(
            controller: controller,
            decoration: const InputDecoration(hintText: 'Enter new username'),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, null);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (controller.text.isNotEmpty) {
                  Navigator.pop(context, controller.text);
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Help me how to use this app'),
          content: const Text(
            '''Welcome to the Help & Support section!
             -Use the search function to find your desired pet or a stray animal (e.g., breed, type, location).- Contact the seller/owner directly via the platform to arrange a meeting.
    - Always inspect the animal in person at a public location before finalizing the adoption.
    - Never pay in advance unless absolutely necessary—your safety is our priority.
    - Ensure the seller's or rescue profile is verified before any transaction.
    - Contact us if you need any assistance with adopting or rescuing animals.''',
            style: TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  void _showResetDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset Settings'),
          content: const Text('Are you sure you want to reset all settings?'),
          actions: [
            TextButton(
              onPressed: () {Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _notificationsEnabled = false;
                  _darkModeEnabled = false;
                  _username = 'full_name';
                  _receiveEmails = false;
                  _hasHelpAccess = false;
                });
                Navigator.pop(context);
              },
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );
  }
}
