import 'package:flutter/material.dart';

import '../databasehelper/db_rescueregis.dart';
import 'buyer side/Rescueshelters.dart';

class RescueShelterDetailsPage extends StatelessWidget {
  final Map<String, dynamic> shelter;

  const RescueShelterDetailsPage({super.key, required this.shelter});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rescue Shelter Details'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Card(
          margin: const EdgeInsets.all(8.0),
          elevation: 5,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Shelter Name', shelter['name'], Icons.pets),
                _buildDetailRow('Location', shelter['location'], Icons.location_on),
                _buildDetailRow('Phone', shelter['phone'], Icons.phone),
                _buildDetailRow('Email', shelter['email'], Icons.email),
                _buildDetailRow('Animal Types', shelter['animal_types'], Icons.category),
                _buildDetailRow('Max Capacity', shelter['max_capacity'].toString(), Icons.people),
                _buildDetailRow('Current Occupancy', shelter['current_occupancy'].toString(), Icons.person_outlined),
                _buildDetailRow('Available Slots', (shelter['max_capacity'] - shelter['current_occupancy']).toString(),
                  Icons.check_circle_outline, valueColor: Colors.green,
                ),
                _buildDetailRow('Description', shelter['description'], Icons.description),
                const SizedBox(height: 24),
                Center(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orangeAccent,
                      padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 12.0),
                      textStyle: const TextStyle(fontSize: 16),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context, MaterialPageRoute(
                        builder: (context) => const RescueShelterListPage(),
                      ),
                      );
                    },
                    child: const Text('Submit'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(
      String title, String value,
      IconData icon, {
        Color? valueColor,
      }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 24, color: Colors.orangeAccent),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title, style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value, style: TextStyle(
                    // fontSize: 12,color: valueColor ?? Colors.black,
                  fontSize: 12,color: valueColor ?? Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

}

class RescueShelterListPage extends StatefulWidget {
  const RescueShelterListPage({super.key});

  @override
  _RescueShelterListPageState createState() => _RescueShelterListPageState();
}

class _RescueShelterListPageState extends State<RescueShelterListPage> {
  List<Map<String, dynamic>> _shelters = [];

  @override
  void initState() {
    super.initState();
    _loadShelters();
  }

  Future<void> _loadShelters() async {
    List<Map<String, dynamic>> shelters = await DatabaseHelper().getShelters();
    setState(() {
      _shelters = shelters;
    });
  }

  void _deleteShelter(int id) async {
    await DatabaseHelper().deleteShelter(id);
    _loadShelters();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Shelter deleted successfully')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rescue Shelters'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: _shelters.isEmpty
          ? const Center(child: Text('No rescue shelters added yet.'))
          : GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 10,
          mainAxisSpacing: 10, childAspectRatio: 0.9,
        ),
        itemCount: _shelters.length,
        itemBuilder: (context, index) {
          final shelter = _shelters[index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context, MaterialPageRoute(
                  builder: (context) => RescueShelterDetailsPage(shelter: shelter),
                ),
              );
            },
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      shelter['name'],
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.location_on, size: 16, color: Colors.orange),
                        const SizedBox(width: 4),
                        Expanded(child: Text(shelter['location'], overflow: TextOverflow.ellipsis)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.pets, size: 16, color: Colors.orange),
                        const SizedBox(width: 4),
                        Expanded(child: Text('Animals: ${shelter['animal_types']}')),
                      ],
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Slots: ${(shelter['max_capacity'] - shelter['current_occupancy'])}',
                          style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteShelter(shelter['id']),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
