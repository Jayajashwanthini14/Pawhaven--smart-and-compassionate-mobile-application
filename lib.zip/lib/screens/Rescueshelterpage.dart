// import 'package:flutter/material.dart';
//
// class RescueShelterPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Add Rescue Shelter'),
//         backgroundColor: Colors.orangeAccent,
//       ),
//       body: const Center(
//         child: Text('Rescue Shelter Page Content Goes Here'),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import '../databasehelper/db_rescueregis.dart';
import 'Rescuedetailpage.dart';

class RescueShelterPage extends StatefulWidget {
  const RescueShelterPage({super.key});

  @override
  _AddRescueShelterPageState createState() => _AddRescueShelterPageState();
}

class _AddRescueShelterPageState extends State<RescueShelterPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _shelterNameController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _maxCapacityController = TextEditingController();
  final TextEditingController _currentOccupancyController = TextEditingController();


  final List<String> _animalTypes = ['Dogs', 'Cats', 'Birds', 'Fish', 'Other'];
  final List<String> _selectedAnimalTypes = [];

  int _vacancy = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Rescue Shelter'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _shelterNameController,
                decoration: const InputDecoration(
                  labelText: 'Shelter Name', border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the shelter name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                  labelText: 'Location (Address)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the location';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a phone number';
                  }
                  if (!RegExp(r'^\d{10}$').hasMatch(value)) {
                    return 'Enter a valid 10-digit phone number';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email Address',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter an email address';
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                    return 'Enter a valid email address';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              const Text('Types of Animals Sheltered',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                children: _animalTypes.map((type) {
                  return FilterChip(
                    label: Text(type),
                    selected: _selectedAnimalTypes.contains(type),
                    onSelected: (selected) {
                      setState(() {
                        if (selected) {
                          _selectedAnimalTypes.add(type);
                        } else {
                          _selectedAnimalTypes.remove(type);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _maxCapacityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Maximum Capacity (Total slots)',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the maximum capacity';
                  }
                  if (int.tryParse(value) == null || int.parse(value) <= 0) {
                    return 'Enter a valid positive number';
                  }
                  return null;
                }, onChanged: _calculateVacancy,
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: _currentOccupancyController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Current Occupancy',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the current occupancy';
                  }
                  if (int.tryParse(value) == null || int.parse(value) < 0) {
                    return 'Enter a valid non-negative number';
                  }
                  return null;
                },
                onChanged: _calculateVacancy,
              ),
              const SizedBox(height: 16),

              Text(
                'Available Slots: $_vacancy',
                style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 24),

              TextFormField(
                controller: _descriptionController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  hintText: 'Provide a brief description about the shelter',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),

              Center(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orangeAccent,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40.0, vertical: 16.0),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      _submitForm();
                    }
                  },
                  child: const Text('Submit', style: TextStyle(fontSize: 16))
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _calculateVacancy(String value) {
    int maxCapacity = int.tryParse(_maxCapacityController.text) ?? 0;
    int currentOccupancy = int.tryParse(_currentOccupancyController.text) ?? 0;

    setState(() {
      _vacancy = maxCapacity - currentOccupancy;
      if (_vacancy < 0) _vacancy = 0;
    });
  }

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      Map<String, dynamic> shelter = {
        'name': _shelterNameController.text,
        'location': _locationController.text,
        'phone': _phoneController.text,
        'email': _emailController.text,
        'description': _descriptionController.text,
        'max_capacity': int.parse(_maxCapacityController.text),
        'current_occupancy': int.parse(_currentOccupancyController.text),
        'animal_types': _selectedAnimalTypes.join(', '),
      };

      await DatabaseHelper().insertShelter(shelter);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Shelter "${_shelterNameController.text}" added successfully!')),
      );
      Navigator.push(
        context, MaterialPageRoute(builder: (context) => RescueShelterDetailsPage(shelter: shelter)),
      );

      _formKey.currentState?.reset();
      setState(() {
        _selectedAnimalTypes.clear();
        _vacancy = 0;
      } );
    }
  }
}
