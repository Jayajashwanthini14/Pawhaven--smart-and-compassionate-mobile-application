// import 'package:flutter/material.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:page_transition/page_transition.dart';
// import '../AddScreen.dart';
// import '../LoginPage.dart';
// import '../LogoutPage.dart';
// import '../Rescueshelterpage.dart';
// import '../SettingsScreen.dart';
// import '../SignupPage.dart';
// import '../buyer side/Accessories.dart';
// import '../buyer side/Rescueshelters.dart';
// import '../buyer side/availability.dart';
// import '../buyer side/pet.dart';
// import '../buyer side/searchbuttonpage.dart';
// import '../buyer side/stray.dart';
// import 'Chatscreen.dart';
// import 'UserScreen.dart';
// import 'favoritespage.dart';
// import 'needsupport.dart';
//
// class HomePage extends StatefulWidget {
//   final String username;
//
//   const HomePage({required this.username, Key? key}) : super(key: key);
//
//   @override
//   _HomePageState createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   int _currentIndex = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text('🐾 Paw Haven 🐾', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
//             Text('Welcome, ${widget.username}', style: const TextStyle(fontSize: 14, color: Colors.white)),
//           ],
//         ),
//         backgroundColor: Colors.orangeAccent,
//         leading: IconButton(
//           icon: const Icon(Icons.menu),
//           onPressed: () {
//             _scaffoldKey.currentState?.openDrawer();
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.search, color: Colors.white),
//             onPressed: () {
//               Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: SearchPage()),
//               );
//             },
//           ),
//         ],
//       ),
//       drawer: _buildCustomDrawer(),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.symmetric(horizontal: 8.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const SizedBox(height: 20),
//             _buildImageCarousel(),
//             const SizedBox(height: 20),
//             _buildGridOptions(),
//             const SizedBox(height: 20),
//             _buildAvailabilityButton(),
//             const SizedBox(height: 20),
//             _buildAddPetCard(),
//             const SizedBox(height: 20),
//             _buildAddRescueShelterCard(),
//           ],
//         ),
//       ),
//       bottomNavigationBar: _buildBottomNavigationBar(),
//     );
//   }
//
//   Widget _buildCustomDrawer() {
//     return Drawer(
//       child: ListView(
//         padding: EdgeInsets.zero,
//         children: [
//           DrawerHeader(
//             decoration: BoxDecoration(
//               color: Colors.pinkAccent,
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Icon(Icons.pets, size: 50, color: Colors.white),
//                 SizedBox(height: 8),
//                 Text(
//                   "🐾 Paw Haven",
//                   style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
//                 ),
//                 SizedBox(height: 4),
//                 Text(
//                   "Helping paws find homes",
//                   style: TextStyle(fontSize: 14, color: Colors.white70),
//                 ),
//               ],
//             ),
//           ),
//           _buildDrawerItem(icon: Icons.pets, title: 'Find Pets', onTap: () => _navigateTo(PetPage())),
//           _buildDrawerItem(icon: Icons.pets, title: 'Starys', onTap: () => _navigateTo(StrayPage())),
//           _buildDrawerItem(icon: Icons.pets, title: 'pet Accessories', onTap: () => _navigateTo(AccessoriesPage())),
//           _buildDrawerItem(icon: Icons.night_shelter_rounded, title: 'Shelters', onTap: () => _navigateTo(ViewRescueSheltersPage())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.add_box_outlined , title: 'Add Pets', onTap: () => _navigateTo(AnimalTypeSelection())),
//           _buildDrawerItem(icon: Icons.add_home_work_sharp , title: 'Add Shelters', onTap: () => _navigateTo(RescueShelterPage())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.favorite_rounded, title: 'Favorites', onTap: () => _navigateTo(FavoritesPage())),
//           _buildDrawerItem(icon: Icons.info, title: 'About', onTap: _showAboutDialog),
//           _buildDrawerItem(icon: Icons.settings, title: 'Settings', onTap: () => _navigateTo(SettingsScreen())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.login, title: 'LogIn', onTap: () => _navigateTo(LoginPage())),
//           _buildDrawerItem(icon: Icons.logout_outlined, title: 'Logout', onTap: () => _navigateTo(LogoutPage())),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildGridOptions() {
//     return GridView.count(
//       shrinkWrap: true, crossAxisCount: 3,
//       mainAxisSpacing: 20.0, crossAxisSpacing: 10.0,
//       physics: NeverScrollableScrollPhysics(),
//       children: [
//         _buildGridTile(icon: Icons.pets, label: 'Pets', onTap: () => _navigateTo(PetPage())),
//         _buildGridTile(icon: Icons.pets, label: 'Strays', onTap: () => _navigateTo(StrayPage())),
//         _buildGridTile(icon: Icons.pets, label: 'Access', onTap: () => _navigateTo(AccessoriesPage())),
//       ],
//     );
//   }
//
//   Widget _buildAvailabilityButton() {
//     return GridView.count(
//       shrinkWrap: true,
//       crossAxisCount: 2,
//       mainAxisSpacing: 20.0,
//       crossAxisSpacing: 10.0,
//       physics: NeverScrollableScrollPhysics(),
//       children: [
//         _buildGridTile(icon: Icons.pets_outlined, label: 'Availability', onTap: () => _navigateTo(AvailabilityScreen())),
//         _buildGridTile(icon: Icons.night_shelter_rounded, label: 'Rescue Shelter', onTap: () => _navigateTo(ViewRescueSheltersPage())),
//       ],
//     );
//   }
//
//   Widget _buildImageCarousel() {
//     List<String> images = ['assets/images/Stray.jpg','assets/images/pp1.jpg'];
//     return CarouselSlider(
//       items: images.isNotEmpty
//           ? images.map((imagePath) {
//         return Image.asset(imagePath, fit: BoxFit.cover);
//       }).toList()
//           : [const Center(child: Text('No images available'))],
//       options: CarouselOptions(height: 180, autoPlay: true, enlargeCenterPage: true, aspectRatio: 16/9),
//     );
//   }
//
//   Widget _buildAddPetCard() {
//     return GestureDetector(
//       onTap: () => _navigateTo(AnimalTypeSelection()),
//       child: Card(
//         elevation: 6.0,
//         shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(12.0),
//         ),
//         child: const Padding(
//           padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 16.0),
//           child: Row(
//             children: [
//               Icon(Icons.add_box_outlined, size: 40, color: Colors.orangeAccent),
//               SizedBox(width: 16),
//               Expanded(child: Text('Add Pets', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildAddRescueShelterCard() {
//     return GestureDetector(
//       onTap: () => _navigateTo(RescueShelterPage()),
//       child: Card(
//         elevation: 6.0, shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(12.0),
//         ),
//         child: const Padding(
//           padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 16.0),
//           child: Row(
//             children: [
//               Icon(Icons.add_home_work_sharp, size: 40, color: Colors.orangeAccent),
//               SizedBox(width: 16),
//               Expanded(
//                 child: Text('Add Rescue Shelter', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildDrawerItem({required IconData icon, required String title, required VoidCallback onTap}) {
//     return ListTile(
//       leading: Icon(icon), title: Text(title),
//       onTap: onTap,
//     );
//   }
//
//   Widget _buildGridTile({required IconData icon, required String label, required VoidCallback onTap}) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(height: 150,
//         child: Card(
//           elevation: 6.0, shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(12.0),
//           ),
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 23.0, vertical: 16.0),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Icon(icon, size: 40, color: Colors.orangeAccent),
//                 const SizedBox(height: 12),
//                 Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildBottomNavigationBar() {
//     return BottomNavigationBar(
//       type: BottomNavigationBarType.fixed,
//       backgroundColor: Colors.orangeAccent,
//       selectedItemColor: Colors.white,
//       unselectedItemColor: Colors.black54,
//       selectedFontSize: 14,
//       unselectedFontSize: 12,
//       iconSize: 28,
//       currentIndex: _currentIndex,
//       onTap: (index) {
//         setState(() => _currentIndex = index);
//         _navigateBasedOnIndex(index);
//       },
//       items: const [
//         BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
//         BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
//         BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorites'),
//         BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
//       ],
//     );
//   }
//
//   void _navigateBasedOnIndex(int index) {
//     switch (index) {
//       case 1:
//         _navigateTo(ChatScreen());
//         break;
//       case 2:
//         _navigateTo(FavoritesPage());
//         break;
//       case 3:
//         _navigateTo(UserScreen());
//         break;
//     }
//   }
//
//   void _navigateTo(Widget page) {
//     Navigator.push(
//       context, PageTransition(type: PageTransitionType.rightToLeft, child: page),
//     );
//   }
//
//   void _showAboutDialog() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('About'),
//         content: const Text('This app helps stray animals by connecting them with prospective adopters.'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('OK'),
//           ),
//         ],
//       ),
//     );
//   }
// }
