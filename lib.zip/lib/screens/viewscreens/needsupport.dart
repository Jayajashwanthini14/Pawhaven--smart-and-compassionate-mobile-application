import 'package:flutter/material.dart';
import '../../Adopters/Adopter_HomeScreen.dart';
import '../../databasehelper/db_needsupport.dart';

class ShelterSupport extends StatefulWidget {
  const ShelterSupport({super.key});

  @override
  _PetShelterSupportFormState createState() => _PetShelterSupportFormState();
}

class _PetShelterSupportFormState extends State<ShelterSupport> {
  final _formKey = GlobalKey<FormState>();
  final DatabaseHelper _dbHelper = DatabaseHelper();

  String? _petName;
  String? _petType;
  String? _petAge;
  String? _healthStatus;
  String? _shelterType;
  String _shelterDuration = 'Short-term';
  String? _ownerName;
  String? _ownerContact;

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      Map<String, dynamic> supportData = {
        'petName': _petName,
        'petType': _petType,
        'petAge': _petAge,
        'healthStatus': _healthStatus,
        'shelterType': _shelterType,
        'shelterDuration': _shelterDuration,
        'ownerName': _ownerName,
        'ownerContact': _ownerContact,
      };

      await _dbHelper.insertsupport(supportData);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Shelter support request submitted successfully!')),
      );

      _formKey.currentState!.reset();
      setState(() {
        _shelterDuration = 'Short-term';
      });

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const ShelterSupportDetailPage(item: {})),
      );
    }
  }

  Widget _buildTextField({
    required String label,
    TextInputType keyboardType = TextInputType.text,
    required FormFieldSetter<String> onSaved,
  }) {
    return TextFormField(
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      keyboardType: keyboardType,
      validator: (value) => value == null || value.isEmpty ? 'This field is required' : null,
      onSaved: onSaved,
    );
  }

  Widget _buildDropdownField({
    required String label,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      items: items.map((String item) {
        return DropdownMenuItem(value: item, child: Text(item));
      }).toList(),
      onChanged: onChanged,
      validator: (value) => value == null ? 'Please select an option' : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pet Shelter Support'),
        backgroundColor: Colors.pinkAccent,
        elevation: 2,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Pet Information',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                _buildTextField(label: 'Pet Name', onSaved: (value) => _petName = value),
                const SizedBox(height: 10),
                _buildTextField(label: 'Type of Pet', onSaved: (value) => _petType = value),
                const SizedBox(height: 10),
                _buildTextField(label: 'Pet Age', onSaved: (value) => _petAge = value),
                const SizedBox(height: 10),
                _buildTextField(
                  label: 'Health Status (Vaccinated, Medical issues, etc.)',
                  onSaved: (value) => _healthStatus = value,
                ),
                const SizedBox(height: 20),
                const Text(
                  'Shelter Support Needed',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                _buildDropdownField(
                  label: 'Select Type of Support',
                  items: ['Temporary Shelter', 'Medical Care', 'Food Assistance', 'Adoption Help'],
                  onChanged: (value) => _shelterType = value,
                ),
                const SizedBox(height: 10),
                const Text(
                  'Duration of Shelter Need',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                Column(
                  children: [
                    RadioListTile(
                      title: const Text('Short-term (few days to weeks)'),
                      value: 'Short-term',
                      groupValue: _shelterDuration,
                      onChanged: (value) {
                        setState(() {
                          _shelterDuration = value.toString();
                        });
                      },
                    ),
                    RadioListTile(
                      title: const Text('Long-term (more than a month)'),
                      value: 'Long-term',
                      groupValue: _shelterDuration,
                      onChanged: (value) {
                        setState(() {
                          _shelterDuration = value.toString();
                        });
                      },
                    ),
                    RadioListTile(
                      title: const Text('Until adoption'),
                      value: 'Until adoption',
                      groupValue: _shelterDuration,
                      onChanged: (value) {
                        setState(() {
                          _shelterDuration = value.toString();
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                  'Owner Contact Information',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                _buildTextField(label: 'Owner Name', onSaved: (value) => _ownerName = value),
                const SizedBox(height: 10),
                _buildTextField(
                  label: 'Owner Contact Number',
                  keyboardType: TextInputType.phone,
                  onSaved: (value) => _ownerContact = value,
                ),
                const SizedBox(height: 20),
                Center(
                  child: ElevatedButton(
                    onPressed: _submitForm,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Submit', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ShelterSupportDetailPage extends StatelessWidget {
  final Map<String, dynamic> item;

  const ShelterSupportDetailPage({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Details of ${item['petName']}'),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            _buildDetailRow(Icons.pets, 'Pet Name', item['petName'] ?? 'N/A'),
            _buildDetailRow(Icons.category, 'Pet Type', item['petType'] ?? 'N/A'),
            _buildDetailRow(Icons.cake, 'Pet Age', item['petAge'] ?? 'N/A'),
            _buildDetailRow(Icons.health_and_safety, 'Health Status', item['healthStatus'] ?? 'N/A'),
            _buildDetailRow(Icons.home, 'Support Type', item['shelterType'] ?? 'N/A'),
            _buildDetailRow(Icons.timer, 'Shelter Duration', item['shelterDuration'] ?? 'N/A'),
            _buildDetailRow(Icons.person, 'Owner Name', item['ownerName'] ?? 'N/A'),
            _buildDetailRow(Icons.phone, 'Owner Contact', item['ownerContact'] ?? 'N/A'),
            const SizedBox(height: 30),

            Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Shelter support request submitted!'),
                    ),
                  );
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AdopterHomepage(username: '',)),
                  );
                },
                icon: const Icon(Icons.check, color: Colors.white),
                label: const Text('Submit Request', style: TextStyle(fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, color: Colors.pinkAccent, size: 24),
          const SizedBox(width: 12),
          Text(
            '$label: ',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 16, color: Colors.black87),
            ),
          ),
        ],
      ),
    );
  }
}


