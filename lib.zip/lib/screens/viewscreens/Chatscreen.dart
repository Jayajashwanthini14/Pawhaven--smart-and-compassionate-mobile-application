import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() {
  runApp(const PawHavenChatbot());
}

class PawHavenChatbot extends StatelessWidget {
  const PawHavenChatbot({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.grey,

      ),
      home: const ChatScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  Database? _database;
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, dynamic>> _chatHistory = [];
  List<Map<String, String>> _responses = [];
  bool _isBotTyping = false;

  // Map of predefined questions to database keywords
  final Map<String, String> _predefinedQuestions = {
    'What should I feed my dog?': 'food',
    'When should I vaccinate my pet?': 'vaccination',
    'What to do if my pet has a fever?': 'fever',
    'How to treat a pet injury?': 'injury',
    'What should I feed my puppy?': 'puppy food',
    'How can I train my dog?': 'dog training',
    'What kind of food do cats need?': 'cat food',
    'How often should I bathe my dog?': 'dog bathing',
    'Should I spay or neuter my pet?': 'spay neuter',
    'What should I do for fleas and ticks?': 'flea tick',
    'What are common health problems in pets?': 'health problems',
    'How can I take care of my dog\'s teeth?': 'dog teeth',
    'How do I potty train my dog?': 'potty',
    'Why does my dog bark so much?': 'dog barking',
    'How do I treat a dog injury?': 'injury',
    'When should my dog get vaccinated?': 'dog vaccination',
    'How should I groom my cat?': 'cat grooming',
    'What should I do for pet separation anxiety?': 'pet separation_anxiety',
    'Should I get pet insurance?': 'insurance',
    'How do I introduce a new pet to my home?': 'introducing pet',
  };

  @override
  void initState() {
    super.initState();
    _initializeDatabase();
    _addBotMessage('Hello! I am your Vet Chatbot. How can I assist you today? 😊');
  }

  Future<void> _initializeDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'chatbot.db'),
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE chat_responses (id INTEGER PRIMARY KEY, question_keyword TEXT, response TEXT)",
        );
      },
      version: 1,
    );
    await _populateDatabase();
  }

  Future<void> _populateDatabase() async {
    final existingData = await _database!.query('chat_responses');
    if (existingData.isEmpty) {
      List<Map<String, String>> initialData = [
        {'question_keyword': 'food', 'response': 'Need a balanced diet with protein, carbs, and fats. Avoid chocolate, grapes, and onions.'},
        {'question_keyword': 'vaccination', 'response': 'Pets need vaccinations for rabies, distemper, and parvovirus. Consult a vet for a schedule.'},
        {'question_keyword': 'fever', 'response': 'Check if your pet’s nose is dry and warm. Normal temperature is 101-102.5°F. Provide water and monitor.'},
        {'question_keyword': 'injury', 'response': 'Clean the wound with warm water. Apply antiseptic and bandage lightly. Visit a vet if it’s deep.'},
        {'question_keyword': 'puppy food', 'response': 'Puppies need high-quality food rich in protein and nutrients. Consult your vet for food recommendations.'},
        {'question_keyword': 'dog training', 'response': 'Training with positive reinforcement and patience is essential. Start with basic commands like sit, stay, and come.'},
        {'question_keyword': 'cat food', 'response': 'Cats need high-protein, meat-based food. Wet and dry food suitable for their age is ideal.'},
        {'question_keyword': 'dog bathing', 'response': 'Dogs generally need a bath every 4-6 weeks, depending on their activity level.'},
        {'question_keyword': 'spay neuter', 'response': 'Most pets should be spayed/neutered between 6-9 months of age, but this can vary.'},
        {'question_keyword': 'flea tick', 'response': 'Use vet-approved flea and tick treatments and regularly check your pet for pests.'},
        {'question_keyword': 'health problems', 'response': 'Common health issues in dogs include allergies, arthritis, and dental problems.'},
        {'question_keyword': 'dog teeth', 'response': 'Regular brushing with pet-safe toothpaste, dental chews, and vet checkups can help maintain oral health.'},
        {'question_keyword': 'potty', 'response': 'Take your puppy outside often, especially after eating, drinking, or playing, to prevent accidents.'},
        {'question_keyword': 'dog barking', 'response': 'Excessive barking can be managed with training, exercise, and stimulation.'},
        {'question_keyword': 'dog vaccination', 'response': 'Follow your vet’s vaccination schedule for puppies and adult dogs to prevent diseases.'},
        {'question_keyword': 'cat grooming', 'response': 'Brush your cat regularly and trim their nails. Keep their ears and eyes clean as well.'},
        {'question_keyword': 'pet separation_anxiety', 'response': 'Gradually leave your pet alone to help them adjust, and consult your vet for severe cases.'},
        {'question_keyword': 'insurance', 'response': 'Pet insurance can help cover unexpected medical costs. Research different plans before choosing one.'},
        {'question_keyword': 'introducing pet', 'response': 'Introduce pets gradually and supervise all interactions. Give them separate spaces initially.'},
      ];
      for (var entry in initialData) {
        await _database!.insert('chat_responses', entry);
      }
    }
    _loadResponses();
  }

  Future<void> _loadResponses() async {
    final responseData = await _database!.query('chat_responses');
    setState(() {
      _responses = responseData.map((e) => {
        'question_keyword': e['question_keyword'] as String,
        'response': e['response'] as String,
      }).toList();
    });
  }

  void _addUserMessage(String message) {
    setState(() {
      _chatHistory.add({'isUser': true, 'message': message, 'timestamp': DateTime.now()});
    });
  }

  void _addBotMessage(String message) {
    setState(() {
      _chatHistory.add({'isUser': false, 'message': message, 'timestamp': DateTime.now()});
    });
  }

  Future<void> _getResponse(String query) async {
    if (query.isEmpty) return;
    _addUserMessage(query);
    _controller.clear();
    setState(() {
      _isBotTyping = true;
    });

    String response = 'Please consult a veterinary doctor for more detailed information.';
    bool isMatched = false;

    // Check predefined questions
    _predefinedQuestions.forEach((question, keyword) {
      if (query.toLowerCase().contains(question.toLowerCase())) {
        final matchedResponse = _responses.firstWhere(
              (entry) => entry['question_keyword'] == keyword,
          orElse: () => {'response': 'Sorry, I couldnt give you proper response with this question ,Please consult a veterinary doctor.'},
        )['response'];
        response = matchedResponse ?? response;
        isMatched = true;
      }
    });

    // If no match was found, look through the database responses
    if (!isMatched) {
      final closestMatch = _responses.firstWhere(
            (entry) => query.toLowerCase().contains(entry['question_keyword']?.toLowerCase() as Pattern),
        orElse: () => {'response': 'Please consult a veterinary doctor  '},
      )['response'];
      response = closestMatch ?? response;
    }

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _isBotTyping = false;
      });
      _addBotMessage(response);
    });
  }

  Widget _buildPredefinedQuestions() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _predefinedQuestions.keys.map((question) {
        return ElevatedButton(
          onPressed: () => _getResponse(question),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blueGrey[600],
            foregroundColor: Colors.white70,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          child: Text(question, style: const TextStyle(fontSize: 14)),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vet Chatbot'),
        backgroundColor: Colors.white70,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Chat history wrapped in ListView to make it scrollable and expandable
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _chatHistory.length,
              itemBuilder: (context, index) {
                bool isUser = _chatHistory[index]['isUser'];
                String message = _chatHistory[index]['message'];

                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.green[100] : Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: const [
                        BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(2, 2)),
                      ],
                    ),
                    child: Text(
                      message,
                      style: const TextStyle(fontSize: 16, color: Colors.black),
                    ),
                  ),
                );
              },
            ),
            if (_isBotTyping)
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    CircularProgressIndicator(strokeWidth: 2),
                    SizedBox(width: 10),
                    Text("Bot is typing...", style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: "Ask something...",
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                        filled: true,
                        fillColor: Colors.white,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    backgroundColor: Colors.green[800],
                    child: IconButton(
                      icon: const Icon(Icons.send, color: Colors.white),
                      onPressed: () => _getResponse(_controller.text),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: _buildPredefinedQuestions(),
            ),
          ],
        ),
      ),
    );
  }
}
