import 'package:flutter/material.dart';
import '../../Adopters/Adopter_HomeScreen.dart';
import '../../databasehelper/db_form.dart';


void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: PetAdoptionForm(),
  ));
}
class PetAdoptionForm extends StatefulWidget {
  const PetAdoptionForm({super.key});

  @override
  _PetAdoptionFormState createState() => _PetAdoptionFormState();
}

class _PetAdoptionFormState extends State<PetAdoptionForm> {
  final _formKey = GlobalKey<FormState>();
  String? name;
  String? contact;
  String? address;
  String? homeType;
  String? ownershipStatus;
  bool? isFenced;
  bool? hasOwnedPet;
  String? reasonForAdoption;
  bool agreeToRules = false;

  void _showAdoptionRules() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Adoption Rules'),
          content: const SingleChildScrollView(
            child: Text(
                  '1. Ensure you have sufficient time and resources for a pet.\n\n'
                  '2. Pets require a loving, safe, and clean environment.\n\n'
                  '3. Provide proper medical care and nutrition.\n\n'
                  '4. Ensure your home is pet-friendly (e.g., safe yard, no toxic items).\n\n'
                  '5. Follow local pet regulations and licensing.\n\n'
                  '6. Commit to the long-term care of the pet, including potential emergencies.',
              style: TextStyle(fontSize: 16),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {Navigator.of(context).pop();
                setState(() {
                  agreeToRules = true;
                });
              },
              child: const Text('I Agree'),
            ),
            TextButton(
              onPressed: () {Navigator.of(context).pop();
                setState(() {
                  agreeToRules = false;
                });
              },
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Adoption Form'),
          backgroundColor: Colors.pinkAccent,
        ),
        body: Padding(
        padding: const EdgeInsets.all(16.0),
    child: Form(
    key: _formKey,
    child: ListView(
    children: [
    TextFormField(
    decoration: const InputDecoration(
    labelText: 'Full Name', border: OutlineInputBorder(),
    ), validator: (value) {
      if (value == null || value.isEmpty) {
        return 'Please enter your name';
    }return null;
    },
      onSaved: (value) => name = value,
    ),
      const SizedBox(height: 16),
      TextFormField(decoration: const InputDecoration(
        labelText: 'Contact Number', border: OutlineInputBorder(),
    ), keyboardType: TextInputType.phone,
        validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your contact number';
    }
        if (!RegExp(r'^\d{10}$').hasMatch(value)) {
          return 'Enter a valid 10-digit phone number';
    }
        return null;
    },
        onSaved: (value) => contact = value,
    ),
      const SizedBox(height: 16),
      TextFormField(
        decoration: const InputDecoration(
          labelText: 'Full Address',
          border: OutlineInputBorder(),
    ), maxLines: 3,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your address';
    }
    return null;
    }, onSaved: (value) => address = value,
    ),
      const SizedBox(height: 16),

      DropdownButtonFormField<String>(decoration: const InputDecoration(
        labelText: 'What type of home do you live in?', border: OutlineInputBorder(),
      ),
        items: const [
          DropdownMenuItem(value: 'Apartment', child: Text('Apartment')),
          DropdownMenuItem(value: 'House', child: Text('House')),
          DropdownMenuItem(value: 'Farm', child: Text('Farm')),
          DropdownMenuItem(value: 'Other', child: Text('Other')),
        ],
        onChanged: (value) => homeType = value,
        validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please select your home type';
        }
        return null;
    },
    onSaved: (value) => homeType = value,
    ),
    const SizedBox(height: 16),

      DropdownButtonFormField<String>(
        decoration: const InputDecoration(
          labelText: 'Do you own or rent your home?',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 'Own', child: Text('Own')),
          DropdownMenuItem(value: 'Rent', child: Text('Rent')),
        ],
        onChanged: (value) => ownershipStatus = value,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please select ownership status';
          }
          return null;
        },
        onSaved: (value) => ownershipStatus = value,
      ),
      const SizedBox(height: 16),

      const Text(
        'Do you have a fenced yard?', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      Row(
        children: [
          Expanded(
            child: RadioListTile<bool>(title: const Text('Yes'), value: true, groupValue: isFenced,
              onChanged: (value) {
                setState(() {
                  isFenced = value;
                });
              },
            ),
          ),
          Expanded(
            child: RadioListTile<bool>(title: const Text('No'), value: false, groupValue: isFenced,
              onChanged: (value) {
                setState(() {isFenced = value;
                });
              },
            ),
          ),
        ],
      ),
      const SizedBox(height: 16),
      const Text('Have you owned a pet before?',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      Row(
        children: [
          Expanded(
            child: RadioListTile<bool>(title: const Text('Yes'), value: true,
              groupValue: hasOwnedPet,
              onChanged: (value) {
                setState(() {hasOwnedPet = value;
                });
              },),
          ),
          Expanded(
            child: RadioListTile<bool>(
              title: const Text('No'),
              value: false,
              groupValue: hasOwnedPet,
              onChanged: (value) {
                setState(() {
                  hasOwnedPet = value;
                });
              },),
          ),],
      ),
      const SizedBox(height: 16),

      TextFormField(
    decoration: const InputDecoration(
    labelText: 'Reason for Adoption',
      border: OutlineInputBorder(),
    ),
      maxLines: 3,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please provide a reason for adoption';
        }
        return null;
      }, onSaved: (value) => reasonForAdoption = value,
    ),
      const SizedBox(height: 16),

      CheckboxListTile(
        title: const Text('I agree to the adoption rules and policies.'),
        value: agreeToRules,
        onChanged: (value) {
          setState(() {
            agreeToRules = value!;
          });
        },
      ),
      const SizedBox(height: 24),

      ElevatedButton(
        onPressed: () async {
          if (_formKey.currentState!.validate() &&
              isFenced != null &&
              hasOwnedPet != null &&
              agreeToRules) {
            _formKey.currentState!.save();

            final formData = {
              'name': name,
              'contact': contact,
              'address': address,
              'homeType': homeType,
              'ownershipStatus': ownershipStatus,
              'isFenced': isFenced! ? 1 : 0,
              'hasOwnedPet': hasOwnedPet! ? 1 : 0,
              'reasonForAdoption': reasonForAdoption,
              'agreeToRules': agreeToRules ? 1 : 0,
            };

            final dbHelper = DatabaseHelper();
            await dbHelper. insertAdoptionForm(formData);
          (formData);

            Navigator.push(
              context, MaterialPageRoute(
                builder: (context) => PreviewScreen(data: formData),
              ),
            );
          } else {
            setState(() {});
          }
        },
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          backgroundColor: Colors.pinkAccent,
        ),
        child: const Text(
          'Submit', style: TextStyle(fontSize: 18),

        ),
      ),
    ],
    ),
    ),
        ),
    );
  }
}


class PreviewScreen extends StatelessWidget {
  final Map<String, dynamic> data;

  const PreviewScreen({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Preview Details'),
        backgroundColor: Colors.pinkAccent,
        elevation: 2,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Preview Your Details',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),

            Card(
              elevation: 4, shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('Name', data['name']),
                    _buildDetailRow('Contact', data['contact']),
                    _buildDetailRow('Address', data['address']),
                    _buildDetailRow('Home Type', data['homeType']),
                    _buildDetailRow('Ownership Status', data['ownershipStatus']),
                    _buildDetailRow('Fenced Yard', data['isFenced'] == 1 ? 'Yes' : 'No'),
                    _buildDetailRow('Previously Owned Pets', data['hasOwnedPet'] == 1 ? 'Yes' : 'No'),
                    _buildDetailRow('Reason for Adoption', data['reasonForAdoption']),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildCompactButton(
                  context: context,
                  label: 'Edit Details',
                  color: Colors.blueAccent,
                  onPressed: () => Navigator.pop(context),
                ),
                _buildCompactButton(
                  context: context,
                  label: 'Submit',
                  color: Colors.green,
                  onPressed: () {
                    _showConfirmationDialog(context);
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  void _showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Submission Successful'),
        content: const Text('Your details have been successfully submitted. Do you need shelter support?'),
        actions: [

          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const AdopterHomepage(username: '',)),
              );
            },
            child: const Text('Submit Form'),
          ),

        ],
      ),
    );
  }


  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '$label:',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.black54,
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactButton({
    required BuildContext context,
    required String label,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        elevation: 3,
        backgroundColor: color,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
    );
  }
}




