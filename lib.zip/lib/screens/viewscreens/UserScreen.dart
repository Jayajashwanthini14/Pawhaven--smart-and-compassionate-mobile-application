import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../LogoutPage.dart';
import 'favoritespage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: const UserScreen(),
    );
  }
}

class UserScreen extends StatefulWidget {
  const UserScreen({super.key});

  @override
  _UserAccountPageState createState() => _UserAccountPageState();
}

class _UserAccountPageState extends State<UserScreen> {
  bool isDarkMode = false;
  String userName = 'full_name';
  String userLocation = "Fetching location...";

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  Future<void> _getUserLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() {
        userLocation = "Location services are disabled";
      });
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        setState(() {
          userLocation = "Location permission denied";
        });
        return;
      }
    }

    try {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      setState(() {
        userLocation = "Lat: ${position.latitude}, Lon: ${position.longitude}";
      });
    } catch (e) {
      setState(() {
        userLocation = "Failed to get location: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account Settings'),
        centerTitle: true,
        elevation: 4,
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Column(
            children: [
              Card(
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 35,
                        backgroundColor: Colors.blueGrey[100],
                        child: Icon(Icons.person, size: 40, color: Colors.grey[800]),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GestureDetector(
                              onTap: () => _editUserName(context),
                              child: Text(
                                userName,
                                style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Tap to edit your username',
                              style: TextStyle(
                                color: Colors.pinkAccent, fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Card(
                margin: const EdgeInsets.only(bottom: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
                ),
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(children: [
                      const Icon(Icons.location_on, size: 40, color: Colors.red),
                      const SizedBox(width: 16), Expanded(
                        child: Text(
                          'Location: $userLocation', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
                ),
                elevation: 3,
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(
                        isDarkMode ? Icons.dark_mode : Icons.light_mode,
                        color: Theme.of(context).primaryColor,
                      ),
                      title: const Text(
                        'Appearance',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                      ),
                      trailing: Switch(
                        value: isDarkMode,
                        onChanged: (value) {
                          setState(() {
                            isDarkMode = value;
                          });
                        },
                      ),
                    ),
                    const Divider(height: 1),

                    _buildTile(
                      icon: Icons.pets,
                      title: 'Adoptions',
                      onTap: () {
                        Navigator.push(
                          context, MaterialPageRoute(builder: (context) => const AdoptionsPage()),
                        );
                      },
                    ),
                    const Divider(height: 1),

                    _buildTile(
                      icon: Icons.favorite,
                      title: 'Favorites',
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => const FavoritesPage()),
                        );
                      },
                    ),
                    const Divider(height: 1),

                    _buildTile(
                      icon: Icons.privacy_tip,
                      title: 'Privacy',
                      onTap: () {
                        Navigator.push(
                          context, MaterialPageRoute(builder: (context) => const PrivacyPage()),
                        );
                      },
                    ),
                    const Divider(height: 1),

                    _buildTile(
                      icon: Icons.logout,
                      title: 'Logout',
                      onTap: () {
                        Navigator.push(
                          context, MaterialPageRoute(builder: (context) => const LogoutPage()),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _editUserName(BuildContext context) async {
    TextEditingController nameController = TextEditingController(text: userName);

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          title: const Text('Edit UserName'),
          content: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'Enter your name',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  userName = nameController.text.trim();
                });
                Navigator.pop(context);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTile({required IconData icon, required String title, VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey[700]),
      title: Text(
        title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
      ),
      onTap: onTap,
    );
  }
}

class AdoptionsPage extends StatelessWidget {
  const AdoptionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adoptions')),
      body: const Center(child: Text('no aniamls Adopted')),
    );
  }
}


class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Privacy Policy'),
        centerTitle: true,
        elevation: 4,
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Privacy Policy - Stray Haven',
                style: TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                '1. Introduction',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'We value your privacy. This policy explains how we collect, use, and protect your data while using Stray Haven.',
              ),
              const SizedBox(height: 16),
              const Text(
                '2. Information We Collect',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'We collect personal details (name, email), location data for matching with pets, and pet information (for adoption purposes).',
              ),
              const SizedBox(height: 16),
              const Text(
                '3. How We Use Your Information',
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'We use your data to help match you with pets, improve the app experience, and communicate adoption updates.',
              ),
              const SizedBox(height: 16),
              const Text(
                '4. How We Protect Your Information',
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'We employ security measures to protect your data. However, no method is 100% secure.',
              ),
              const SizedBox(height: 16),
              const Text(
                '5. Sharing Your Information',
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'We may share your data with shelters or service providers to facilitate the adoption process, as needed.',
              ),
              const SizedBox(height: 16),
              const Text(
                '6. Your Rights',
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'You can access, update, or delete your data anytime. You can also opt out of marketing communications.',
              ),
              const SizedBox(height: 16),
              const Text(
                '7. Contact Us',
                style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.bold,
                ),
              ),
              const Text(
                'For any privacy concerns, contact us at:\nsupport@strayhavenapp.com',
              ),
              const SizedBox(height: 30),

              Center(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text(
                    'Back to Previous Page', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
