import 'dart:io';
import 'package:flutter/material.dart';
import '../../databasehelper/db_helper.dart';
import '../buyer side/animalsdetailsadopt.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  _FavoritesPageState createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  Future<List<Map<String, dynamic>>> fetchFavorites() async {
    try {
      return await DatabaseHelper.instance.fetchFavorites();
    } catch (e) {
      debugPrint("Error fetching favorites: $e");
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorites'),
        backgroundColor: Colors.pinkAccent,
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchFavorites(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No favorites yet.'));
          } else {
            final favoriteAnimals = snapshot.data!;
            return ListView.builder(
              itemCount: favoriteAnimals.length,
              itemBuilder: (context, index) {
                final animal = favoriteAnimals[index];
                final imagePath = animal['imagePath'];

                return Card(
                  margin: const EdgeInsets.symmetric(
                      vertical: 8.0, horizontal: 12.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 4,
                  child: ListTile(
                    onTap: () {
                      Navigator.push(
                        context, MaterialPageRoute(builder: (context) => Detailshere(animal: animal),
                        ),
                      );
                    },
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: imagePath != null && File(imagePath).existsSync()
                          ? Image.file(
                        File(imagePath), width: 50, height: 50, fit: BoxFit.cover,
                      )
                          : Container(
                        width: 50, height: 50,
                        color: Colors.grey[300], child: const Icon(
                          Icons.image, color: Colors.grey,
                        ),
                      ),
                    ),
                    title: Text(
                      animal['animalType'] == 'Accessory'
                          ? animal['productName'] ?? 'Unnamed Product'
                          : animal['title'] ?? 'Unnamed Animal',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text('Type: ${animal['animalType']}'),
                    trailing: IconButton(
                      icon: const Icon(
                        Icons.favorite, color: Colors.red,
                      ),
                      onPressed: () async {
                        await DatabaseHelper.instance.updateFavoriteStatus(
                          animal['id'],
                          false,
                        );
                        setState(() {});
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              '${animal['animalType'] == 'Accessory' ? animal['productName']
                                  : animal['title']} removed from favorites.',
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
