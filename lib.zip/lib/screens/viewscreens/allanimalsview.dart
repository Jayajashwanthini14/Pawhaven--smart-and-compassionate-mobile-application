import  'dart:io';
import 'package:flutter/material.dart';
import '../../Petgiver/PetGiver_homepage.dart';
import '../../databasehelper/db_helper.dart';


class StoredAnimalsScreen extends StatefulWidget {
  const StoredAnimalsScreen({super.key});

  @override
  State<StoredAnimalsScreen> createState() => _StoredAnimalsScreenState();
}

class _StoredAnimalsScreenState extends State<StoredAnimalsScreen> {
  Future<List<Map<String, dynamic>>>? animalsFuture;

  @override
  void initState() {
    super.initState();
    _refreshAnimals();
  }

  void _refreshAnimals() {
    setState(() {
      animalsFuture = DatabaseHelper.instance.fetchAnimals();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stored Animals'),
        backgroundColor: Colors.pinkAccent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const PetgiverHomepage(username: '',)),
              );
            }
          },
        ),


      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: animalsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('No animals stored yet.', style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          } else {
            final animals = snapshot.data!;
            return ListView.separated(
              padding: const EdgeInsets.all(12.0),
              separatorBuilder: (context, index) => const SizedBox(height: 12.0),
              itemCount: animals.length,
              itemBuilder: (context, index) {
                final animal = animals[index];
                final imagePath = animal['imagePath'];

                return Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    leading: imagePath != null && File(imagePath).existsSync()
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(8.0),
                      child: Image.file(
                        File(imagePath),
                        width: 60, height: 60, fit: BoxFit.cover,
                      ),
                    )
                        : const Icon(
                      Icons.image, size: 60, color: Colors.grey,
                    ),
                    title: Text(
                      // animal['title'] ?? 'Unnamed Animal',
                      animal['animalType'] == 'Accessory'
                          ? animal['productName'] ?? 'Unnamed Product'
                          : animal['title'] ?? 'Unnamed Animal',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),

                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Type: ${animal['animalType'] ?? 'N/A'}'),
                        Text('Price: \$${animal['price'] ?? 'N/A'}'),
                        Text('Reason: ${animal['reason'] ?? 'N/A'}',
                          style: const TextStyle(color: Colors.redAccent),
                        ),
                      ],
                    ),


                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(
                            animal['favorite'] == 1 ? Icons.favorite : Icons.favorite_border,
                            color: Colors.pink,
                          ),
                          onPressed: () async {
                            await DatabaseHelper.instance.updateFavoriteStatus(
                              animal['id'],
                              animal['favorite'] != 1,
                            );
                            _refreshAnimals();
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(animal['favorite'] == 1
                                    ? 'Removed from favorites'
                                    : 'Added to favorites'),
                              ),
                            );
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () async {
                            await DatabaseHelper.instance.deleteAnimal(animal['id']);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Animal deleted!')),
                            );
                            _refreshAnimals();
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}





