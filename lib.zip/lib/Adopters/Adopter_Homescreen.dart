// import 'package:flutter/material.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:page_transition/page_transition.dart';
// import '../screens/LoginPage.dart';
// import '../screens/LogoutPage.dart';
// import '../screens/SettingsScreen.dart';
// import '../screens/buyer side/Accessories.dart';
// import '../screens/buyer side/Rescueshelters.dart';
// import '../screens/buyer side/availability.dart';
// import '../screens/buyer side/pet.dart';
// import '../screens/buyer side/searchbuttonpage.dart';
// import '../screens/buyer side/stray.dart';
// import '../screens/viewscreens/Chatscreen.dart';
// import '../screens/viewscreens/UserScreen.dart';
// import '../screens/viewscreens/favoritespage.dart';
//
// class AdopterHomepage extends StatefulWidget {
//   final String username;
//
//   const AdopterHomepage({required this.username, Key? key}) : super(key: key);
//
//   @override
//   _HomePageState createState() => _HomePageState();
// }
//
// class _HomePageState extends State<AdopterHomepage> {
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   int _currentIndex = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text('🐾 Paw Haven 🐾', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
//             // Text('Welcome, ${widget.username}', style: const TextStyle(fontSize: 14, color: Colors.white)),
//             Text('Choose your Perfect Paw Here', style: const TextStyle(fontSize: 14, color: Colors.black)),
//           ],
//         ),
//         backgroundColor: Colors.orangeAccent,
//         leading: IconButton(
//           icon: const Icon(Icons.menu),
//           onPressed: () {
//             _scaffoldKey.currentState?.openDrawer();
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.search, color: Colors.white),
//             onPressed: () {
//               Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: SearchPage()),
//               );
//             },
//           ),
//         ],
//       ),
//       drawer: _buildCustomDrawer(),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.symmetric(horizontal: 8.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const SizedBox(height: 20),
//             _buildImageCarousel(),
//             const SizedBox(height: 20),
//             _buildListOptions(),
//             const SizedBox(height: 20),
//             _buildAvailabilityButton(),
//             const SizedBox(height: 20),
//           ],
//         ),
//       ),
//       bottomNavigationBar: _buildBottomNavigationBar(),
//     );
//   }
//
//   Widget _buildCustomDrawer() {
//     return Drawer(
//       child: ListView(
//         padding: EdgeInsets.zero,
//         children: [
//           DrawerHeader(
//             decoration: BoxDecoration(
//               color: Colors.orangeAccent,
//             ),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Icon(Icons.pets, size: 50, color: Colors.white),
//                 SizedBox(height: 8),
//                 Text(
//                   "🐾 Paw Haven",
//                   style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
//                 ),
//                 SizedBox(height: 4),
//                 Text(
//                   "Helping paws find homes",
//                   style: TextStyle(fontSize: 14, color: Colors.white70),
//                 ),
//               ],
//             ),
//           ),
//           _buildDrawerItem(icon: Icons.pets, title: ' Pets', onTap: () => _navigateTo(PetPage())),
//           _buildDrawerItem(icon: Icons.pets, title: ' Starys', onTap: () => _navigateTo(StrayPage())),
//           _buildDrawerItem(icon: Icons.pets, title: 'pet Accessories', onTap: () => _navigateTo(AccessoriesPage())),
//           _buildDrawerItem(icon: Icons.night_shelter_rounded, title: 'Shelters', onTap: () => _navigateTo(ViewRescueSheltersPage())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.favorite_rounded, title: 'Favorites', onTap: () => _navigateTo(FavoritesPage())),
//           _buildDrawerItem(icon: Icons.info, title: 'About', onTap: _showAboutDialog),
//           _buildDrawerItem(icon: Icons.settings, title: 'Settings', onTap: () => _navigateTo(SettingsScreen())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.login, title: 'LogIn', onTap: () => _navigateTo(LoginPage())),
//           _buildDrawerItem(icon: Icons.logout_outlined, title: 'Logout', onTap: () => _navigateTo(LogoutPage())),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildListOptions() {
//     return ListView(
//       shrinkWrap: true,
//       children: [
//         _buildListTile(icon: Icons.pets, label: 'Pets', onTap: () => _navigateTo(PetPage())),
//         _buildListTile(icon: Icons.pets, label: 'Strays', onTap: () => _navigateTo(StrayPage())),
//         _buildListTile(icon: Icons.pets, label: 'Accessories', onTap: () => _navigateTo(AccessoriesPage())),
//       ],
//     );
//   }
//
//   Widget _buildAvailabilityButton() {
//     return ListView(
//       shrinkWrap: true,
//       children: [
//         _buildListTile(icon: Icons.night_shelter_rounded, label: 'Rescue Shelter', onTap: () => _navigateTo(ViewRescueSheltersPage())),
//       ],
//     );
//   }
//
//   Widget _buildListTile({required IconData icon, required String label, required VoidCallback onTap}) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Card(
//         elevation: 6.0,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
//         margin: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 8.0),
//         child: Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Row(
//             children: [
//               Icon(icon, size: 40, color: Colors.orangeAccent),
//               const SizedBox(width: 16),
//               Expanded(
//                 child: Text(
//                   label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                 ),
//               ),
//               const Icon(Icons.arrow_forward_ios, size: 20),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildImageCarousel() {
//     List<String> images = ['assets/images/Stray.jpg','assets/images/pp1.jpg','assets/images/pp2.jpg'];
//     return CarouselSlider(
//       items: images.isNotEmpty
//           ? images.map((imagePath) {
//         return Image.asset(imagePath, fit: BoxFit.cover);
//       }).toList()
//           : [const Center(child: Text('No images available'))],
//       options: CarouselOptions(height: 180, autoPlay: true, enlargeCenterPage: true, aspectRatio: 16/9),
//     );
//   }
//
//   Widget _buildDrawerItem({required IconData icon, required String title, required VoidCallback onTap}) {
//     return ListTile(
//       leading: Icon(icon), title: Text(title),
//       onTap: onTap,
//     );
//   }
//
//   Widget _buildBottomNavigationBar() {
//     return BottomNavigationBar(
//       type: BottomNavigationBarType.fixed,
//       backgroundColor: Colors.orangeAccent,
//       selectedItemColor: Colors.white,
//       unselectedItemColor: Colors.black54,
//       selectedFontSize: 14,
//       unselectedFontSize: 12,
//       iconSize: 28,
//       currentIndex: _currentIndex,
//       onTap: (index) {
//         setState(() => _currentIndex = index);
//         _navigateBasedOnIndex(index);
//       },
//       items: const [
//         BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
//         BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
//         BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorites'),
//         BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
//       ],
//     );
//   }
//
//   void _navigateBasedOnIndex(int index) {
//     switch (index) {
//       case 1:
//         _navigateTo(ChatScreen());
//         break;
//       case 2:
//         _navigateTo(FavoritesPage());
//         break;
//       case 3:
//         _navigateTo(UserScreen());
//         break;
//     }
//   }
//
//   void _navigateTo(Widget page) {
//     Navigator.push(
//       context, PageTransition(type: PageTransitionType.rightToLeft, child: page),
//     );
//   }
//
//   void _showAboutDialog() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('About'),
//         content: const Text('This app helps stray animals by connecting them with prospective adopters.'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('OK'),
//           ),
//         ],
//       ),
//     );
//   }
// }
//

//
// import 'package:flutter/material.dart';
// import 'package:carousel_slider/carousel_slider.dart';
//
// import '../Theme/Color.dart';
// import '../screens/buyer side/Accessories.dart';
// import '../screens/buyer side/Rescueshelters.dart';
// import '../screens/buyer side/pet.dart';
// import '../screens/buyer side/stray.dart';
// import '../screens/viewscreens/UserScreen.dart';
// import '../screens/viewscreens/favoritespage.dart';
// import '../screens/viewscreens/Chatscreen.dart';
// import '../screens/LoginPage.dart';
// import '../screens/LogoutPage.dart';
// import '../screens/SettingsScreen.dart';
//
// class AdopterHomepage extends StatefulWidget {
//   const AdopterHomepage({super.key, required String username});
//
//   @override
//   _AdopterHomepageState createState() => _AdopterHomepageState();
// }
//
// class _AdopterHomepageState extends State<AdopterHomepage> {
//   int _selectedIndex = 0;
//
//   final List<String> _carouselImages = [
//     'assets/images/pp1.jpg',
//     'assets/images/pp2.jpg',
//     'assets/images/Stray.jpg',
//   ];
//
//   void _navigateToPage(Widget page) {
//     Navigator.push(context, MaterialPageRoute(builder: (context) => page));
//   }
//
//   void _onItemTapped(int index) {
//     switch (index) {
//       case 0:
//         _navigateToPage(const AdopterHomepage(username: '',));
//         break;
//       case 1:
//         _navigateToPage(const FavoritesPage());
//         break;
//       case 2:
//         _navigateToPage(ChatScreen());
//         break;
//       case 3:
//         _navigateToPage(UserScreen());
//         break;
//     }
//     setState(() {
//       _selectedIndex = index;
//     });
//   }
//
//   Widget _buildDrawerItem({
//     required IconData icon,
//     required String title,
//     required Widget page,
//   }) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.black54),
//       title: Text(
//         title,
//         style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
//       ),
//       onTap: () {
//         Navigator.pop(context);
//         _navigateToPage(page);
//       },
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         title: const Text(
//           'Stray Haven',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//       ),
//       drawer: Drawer(
//         child: Column(
//           children: [
//             DrawerHeader(
//               decoration: BoxDecoration(color: AppColor.primary),
//               child: const Center(
//                 child: Text(
//                   'Menu',
//                   style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ),
//             _buildDrawerItem(icon: Icons.pets, title: 'Pets', page: const PetPage()),
//             _buildDrawerItem(icon: Icons.nature_people, title: 'Strays', page: const StrayPage()),
//             _buildDrawerItem(icon: Icons.shopping_bag, title: 'Accessories', page: const AccessoriesPage()),
//             _buildDrawerItem(icon: Icons.favorite, title: 'Favorites', page: const FavoritesPage()),
//             _buildDrawerItem(icon: Icons.chat, title: 'Chat', page: ChatScreen()),
//             _buildDrawerItem(icon: Icons.person, title: 'Profile', page: UserScreen()),
//             const Divider(),
//             _buildDrawerItem(icon: Icons.settings, title: 'Settings', page: const SettingsScreen()),
//             _buildDrawerItem(icon: Icons.login, title: 'Log In', page: const LoginPage()),
//             _buildDrawerItem(icon: Icons.logout, title: 'Logout', page: const LogoutPage()),
//           ],
//         ),
//       ),
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 10),
//
//           // Carousel Slider with Images
//           CarouselSlider.builder(
//             itemCount: _carouselImages.length,
//             options: CarouselOptions(
//               height: 200,
//               enlargeCenterPage: true,
//               autoPlay: true,
//               aspectRatio: 16 / 9,
//               autoPlayCurve: Curves.fastOutSlowIn,
//               enableInfiniteScroll: true,
//               autoPlayAnimationDuration: const Duration(milliseconds: 800),
//               viewportFraction: 0.85,
//             ),
//             itemBuilder: (context, index, realIndex) {
//               return ClipRRect(
//                 borderRadius: BorderRadius.circular(15),
//                 child: Image.asset(_carouselImages[index], fit: BoxFit.cover),
//               );
//             },
//           ),
//
//           const SizedBox(height: 20),
//
//
//           // Category Buttons with Navigation
//           SizedBox(
//             height: 120,
//             child: ListView(
//               scrollDirection: Axis.horizontal,
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               children: [
//                 _buildCategoryButton(context, 'Pets', Icons.pets, const PetPage()),
//                 _buildCategoryButton(context, 'Strays', Icons.nature_people, const StrayPage()),
//                 _buildCategoryButton(context, 'Accessories', Icons.shopping_bag, const AccessoriesPage()),
//
//               ],
//             ),
//           ),
//         ],
//       ),
//       bottomNavigationBar: BottomNavigationBar(
//         backgroundColor: Colors.white,
//         selectedItemColor: AppColor.secondary,
//         unselectedItemColor: Colors.grey,
//         type: BottomNavigationBarType.fixed,
//         currentIndex: _selectedIndex,
//         onTap: _onItemTapped,
//         showSelectedLabels: true,
//         selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
//         elevation: 0,
//         items: const [
//           BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 30), label: 'Home'),
//           BottomNavigationBarItem(icon: Icon(Icons.favorite_border, size: 30), label: 'Favorites'),
//           BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline, size: 30), label: 'Chat'),
//           BottomNavigationBarItem(icon: Icon(Icons.person_outline, size: 30), label: 'Profile'),
//         ],
//       ),
//     );
//   }
// }
//
// Widget _buildCategoryButton(BuildContext context, String category, IconData icon, Widget page) {
//   return GestureDetector(
//     onTap: () {
//       Navigator.push(context, MaterialPageRoute(builder: (context) => page));
//     },
//     child: Column(
//       children: [
//         Container(
//           width: 90,
//           height: 90,
//           decoration: BoxDecoration(
//             borderRadius: BorderRadius.circular(15),
//             color: AppColor.secondary,
//           ),
//           child: Icon(icon, size: 45, color: Colors.white),
//         ),
//         const SizedBox(height: 7),
//         Text(
//           category,
//           style: const TextStyle(
//             fontSize: 16,
//             fontWeight: FontWeight.bold,
//             color: Colors.black,
//           ),
//         ),
//       ],
//     ),
//   );
// }
//
//
//
//
// //
// // // Dummy pages
// // class PetPage extends StatelessWidget { const PetPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Pets"))); }
// // class StrayPage extends StatelessWidget { const StrayPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Strays"))); }
// // class AccessoriesPage extends StatelessWidget { const AccessoriesPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Pet Accessories"))); }
// // class ViewRescueSheltersPage extends StatelessWidget { const ViewRescueSheltersPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Rescue Shelters"))); }
// // class FavoritesScreen extends StatelessWidget { const FavoritesScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Favorites"))); }
// // class UserScreen extends StatelessWidget { const UserScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("User Profile"))); }
// class AboutPage extends StatelessWidget { const AboutPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("About"))); }
// // class SettingsScreen extends StatelessWidget { const SettingsScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Settings"))); }
// // class LoginPage extends StatelessWidget { const LoginPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Favorites"))); }
// // class LogoutPage extends StatelessWidget { const LogoutPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text("Favorites"))); }
// //


// import 'package:flutter/material.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:untitled4/screens/buyer%20side/availability.dart';
//
// import '../Theme/Color.dart';
// import '../screens/buyer side/Accessories.dart';
// import '../screens/buyer side/Rescueshelters.dart';
// import '../screens/buyer side/pet.dart';
// import '../screens/buyer side/stray.dart';
// import '../screens/viewscreens/UserScreen.dart';
// import '../screens/viewscreens/favoritespage.dart';
// import '../screens/viewscreens/Chatscreen.dart';
// import '../screens/LoginPage.dart';
// import '../screens/LogoutPage.dart';
// import '../screens/SettingsScreen.dart';
//
// class AdopterHomepage extends StatefulWidget {
//   const AdopterHomepage({super.key, required String username});
//
//   @override
//   _AdopterHomepageState createState() => _AdopterHomepageState();
// }
//
// class _AdopterHomepageState extends State<AdopterHomepage> {
//   int _selectedIndex = 0;
//   String _selectedCategory = 'All'; // Default selected category
//
//   final List<String> _carouselImages = [
//     'assets/images/pp1.jpg',
//     'assets/images/pp2.jpg',
//     'assets/images/Stray.jpg',
//   ];
//
//   Widget _buildCategoryButton(BuildContext context, String category, IconData icon) {
//     bool isSelected = _selectedCategory == category;
//
//     return GestureDetector(
//       onTap: () {
//         setState(() {
//           _selectedCategory = category; // Update selected category
//         });
//       },
//       child: Column(
//         children: [
//           Container(
//             width: 90,
//             height: 90,
//             decoration: BoxDecoration(
//               borderRadius: BorderRadius.circular(15),
//               color: isSelected ? AppColor.primary : AppColor.secondary,
//             ),
//             child: Icon(icon, size: 45, color: Colors.white),
//           ),
//           const SizedBox(height: 7),
//           Text(
//             category,
//             style: TextStyle(
//               fontSize: 16,
//               fontWeight: FontWeight.bold,
//               color: isSelected ? AppColor.primary : Colors.black,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _getSelectedCategoryWidget() {
//     switch (_selectedCategory) {
//       case 'All':
//         return const AvailabilityScreen();
//       case 'Pets':
//         return const PetPage();
//       case 'Strays':
//         return const StrayPage();
//       case 'Accessories':
//         return const AccessoriesPage();
//       default:
//         return Container(); // Default empty container
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         title: const Text(
//           'Stray Haven',
//           style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
//         ),
//       ),
//       drawer: Drawer(
//         child: Column(
//           children: [
//             DrawerHeader(
//               decoration: BoxDecoration(color: AppColor.primary),
//               child: const Center(
//                 child: Text(
//                   'Menu',
//                   style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
//                 ),
//               ),
//             ),
//             _buildDrawerItem(icon: Icons.all_inbox_outlined, title: 'All', page: const AvailabilityScreen()),
//             _buildDrawerItem(icon: Icons.pets, title: 'Pets', page: const PetPage()),
//             _buildDrawerItem(icon: Icons.nature_people, title: 'Strays', page: const StrayPage()),
//             _buildDrawerItem(icon: Icons.shopping_bag, title: 'Accessories', page: const AccessoriesPage()),
//             const Divider(),
//             _buildDrawerItem(icon: Icons.favorite, title: 'Favorites', page: const FavoritesPage()),
//             _buildDrawerItem(icon: Icons.chat, title: 'Chat', page: ChatScreen()),
//             _buildDrawerItem(icon: Icons.person, title: 'Profile', page: UserScreen()),
//             const Divider(),
//             _buildDrawerItem(icon: Icons.settings, title: 'Settings', page: const SettingsScreen()),
//             _buildDrawerItem(icon: Icons.login, title: 'Log In', page: const LoginPage()),
//             _buildDrawerItem(icon: Icons.logout, title: 'Logout', page: const LogoutPage()),
//           ],
//         ),
//       ),
//       body: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           const SizedBox(height: 10),
//
//           // Carousel Slider with Images
//           CarouselSlider.builder(
//             itemCount: _carouselImages.length,
//             options: CarouselOptions(
//               height: 200,
//               enlargeCenterPage: true,
//               autoPlay: true,
//               aspectRatio: 16 / 9,
//               autoPlayCurve: Curves.fastOutSlowIn,
//               enableInfiniteScroll: true,
//               autoPlayAnimationDuration: const Duration(milliseconds: 800),
//               viewportFraction: 0.85,
//             ),
//             itemBuilder: (context, index, realIndex) {
//               return ClipRRect(
//                 borderRadius: BorderRadius.circular(15),
//                 child: Image.asset(_carouselImages[index], fit: BoxFit.cover),
//               );
//             },
//           ),
//
//           const SizedBox(height: 20),
//
//           // Category Buttons
//           SizedBox(
//             height: 120,
//             child: ListView(
//               scrollDirection: Axis.horizontal,
//               padding: const EdgeInsets.symmetric(horizontal: 16),
//               children: [
//                 _buildCategoryButton(context, 'All', Icons.all_inbox),
//                 const SizedBox(width: 15),
//                 _buildCategoryButton(context, 'Pets', Icons.pets),
//                 const SizedBox(width: 15),
//                 _buildCategoryButton(context, 'Strays', Icons.nature_people),
//                 const SizedBox(width: 15),
//                 _buildCategoryButton(context, 'Accessories', Icons.shopping_bag),
//               ],
//             ),
//           ),
//
//           const SizedBox(height: 20),
//
//           // Display selected category's widget
//           Expanded(
//             child: _getSelectedCategoryWidget(),
//           ),
//         ],
//       ),
//       bottomNavigationBar: BottomNavigationBar(
//         backgroundColor: Colors.white,
//         selectedItemColor: AppColor.secondary,
//         unselectedItemColor: Colors.grey,
//         type: BottomNavigationBarType.fixed,
//         currentIndex: _selectedIndex,
//         onTap: (index) {
//           setState(() {
//             _selectedIndex = index;
//           });
//         },
//         showSelectedLabels: true,
//         selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
//         elevation: 0,
//         items: const [
//           BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 30), label: 'Home'),
//           BottomNavigationBarItem(icon: Icon(Icons.favorite_border, size: 30), label: 'Favorites'),
//           BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline, size: 30), label: 'Chat'),
//           BottomNavigationBarItem(icon: Icon(Icons.person_outline, size: 30), label: 'Profile'),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildDrawerItem({
//     required IconData icon,
//     required String title,
//     required Widget page,
//   }) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.black54),
//       title: Text(
//         title,
//         style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
//       ),
//       onTap: () {
//         Navigator.pop(context);
//         Navigator.push(context, MaterialPageRoute(builder: (context) => page));
//       },
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:page_transition/page_transition.dart';
import 'package:untitled4/screens/buyer%20side/availability.dart';

import '../Theme/Color.dart';
import '../screens/buyer side/Accessories.dart';
import '../screens/buyer side/pet.dart';
import '../screens/buyer side/searchbuttonpage.dart';
import '../screens/buyer side/stray.dart';
import '../screens/viewscreens/UserScreen.dart';
import '../screens/viewscreens/favoritespage.dart';
import '../screens/viewscreens/Chatscreen.dart';
import '../screens/LoginPage.dart';
import '../screens/LogoutPage.dart';
import '../screens/SettingsScreen.dart';

class AdopterHomepage extends StatefulWidget {
  const AdopterHomepage({super.key, required String username});

  @override
  _AdopterHomepageState createState() => _AdopterHomepageState();
}

class _AdopterHomepageState extends State<AdopterHomepage> {
  int _selectedIndex = 0;
  String _selectedCategory = 'All'; // Default selected category

  final List<String> _carouselImages = [
    'assets/images/pp1.jpg',
    'assets/images/pp2.jpg',
    'assets/images/Stray.jpg',
  ];

  void _navigateToPage(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => page));
  }

  void _onTappedItem(int index) {
    switch (index) {
      case 0:
        _navigateToPage(const AdopterHomepage(username: '',));
        break;
      case 1:
        _navigateToPage(const FavoritesPage());
        break;
      case 2:
        _navigateToPage(const ChatScreen());
        break;
      case 3:
        _navigateToPage(const UserScreen());
        break;
    }
    setState(() {
      _selectedIndex = index;
    });
  }


  Widget _buildCategoryButton(BuildContext context, String category,
      IconData icon) {
    bool isSelected = _selectedCategory == category;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedCategory = category; // Update selected category
        });
      },
      child: Column(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: isSelected ? AppColor.primary : AppColor.secondary,
            ),
            child: Icon(icon, size: 30, color: Colors.white),
          ),
          const SizedBox(height: 5),
          Text(
            category,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isSelected ? AppColor.primary : Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _getSelectedCategoryWidget() {
    switch (_selectedCategory) {
      case 'All':
        return const AvailabilityScreen(showAppBar: false);
      case 'Pets':
        return const PetPage(showAppBar: false);
      case 'Strays':
        return const StrayPage(showAppBar: false);
      case 'Accessories':
        return const AccessoriesPage(showAppBar: false);
      default:
        return Container(); // Default empty container
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          '🐾 Paw Haven 🐾', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
          actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.black),
            onPressed: () {
              Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: const SearchPage()),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Column(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: AppColor.primary),
              child: Center(
                child: Text('Menu',
                  style: TextStyle(color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
            _buildDrawerItem(context: context,
                icon: Icons.all_inbox_outlined,
                title: 'All',
                page: const AvailabilityScreen()),
            _buildDrawerItem(context: context,
                icon: Icons.pets,
                title: 'Pets',
                page: const PetPage()),
            _buildDrawerItem(context: context,
                icon: Icons.nature_people,
                title: 'Strays',
                page: const StrayPage()),
            _buildDrawerItem(context: context,
                icon: Icons.shopping_bag,
                title: 'Accessories',
                page: const AccessoriesPage()),
            const Divider(),
            _buildDrawerItem(context: context,
                icon: Icons.favorite,
                title: 'Favorites',
                page: const FavoritesPage()),
            _buildDrawerItem(context: context,
                icon: Icons.chat,
                title: 'Chat',
                page: const ChatScreen()),
            _buildDrawerItem(context: context,
                icon: Icons.person,
                title: 'Profile',
                page: const UserScreen()),
            const Divider(),
            _buildDrawerItem(context: context,
                icon: Icons.settings,
                title: 'Settings',
                page: const SettingsScreen()),
            _buildDrawerItem(context: context,
                icon: Icons.login,
                title: 'Log In',
                page: const LoginPage()),
            _buildDrawerItem(context: context,
                icon: Icons.logout,
                title: 'Logout',
                page: const LogoutPage()),
          ],
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),

          // Carousel Slider with Images
          CarouselSlider.builder(
            itemCount: _carouselImages.length,
            options: CarouselOptions(
              height: 200,
              enlargeCenterPage: true,
              autoPlay: true,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.fastOutSlowIn,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: const Duration(milliseconds: 800),
              viewportFraction: 0.85,
            ),
            itemBuilder: (context, index, realIndex) {
              return ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.asset(_carouselImages[index], fit: BoxFit.cover),
              );
            },
          ),

          const SizedBox(height: 20),

          // Category Buttons
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildCategoryButton(context, 'All', Icons.all_inbox),
                const SizedBox(width: 15),
                _buildCategoryButton(context, 'Pets', Icons.pets),
                const SizedBox(width: 15),
                _buildCategoryButton(context, 'Strays', Icons.nature_people),
                const SizedBox(width: 15),
                _buildCategoryButton(
                    context, 'Accessories', Icons.shopping_bag),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Display selected category's widget
          Expanded(
            child: _getSelectedCategoryWidget(),
          ),
        ],
      ),

        bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: AppColor.secondary,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onTappedItem,
        showSelectedLabels: true,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
        elevation: 0,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined, size: 30), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_border, size: 30), label: 'Favorites'),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline, size: 30), label: 'Chat'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline, size: 30), label: 'Profile'),
        ],
      ),
    );
  }
}

  Widget _buildDrawerItem({
    required BuildContext context,
    required IconData icon,
    required String title,
    required Widget page,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.black54),
      title: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
      ),
      onTap: () {
        Navigator.pop(context);
        Navigator.push(context, MaterialPageRoute(builder: (context) => page));
      },
    );
  }

