// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:flutter/material.dart';
// import 'package:page_transition/page_transition.dart';
// import 'package:untitled4/screens/viewscreens/allanimalsview.dart';
// import '../Adopters/Adopter_HomeScreen.dart';
// import '../screens/AddScreen.dart';
// import '../screens/LoginPage.dart';
// import '../screens/LogoutPage.dart';
// import '../screens/SettingsScreen.dart';
// import '../screens/buyer side/searchbuttonpage.dart';
// import 'approvereq.dart';
//
// class PetgiverHomepage extends StatefulWidget {
//   final String username;
//
//   const PetgiverHomepage({required this.username, Key? key}) : super(key: key);
//
//   @override
//   _HomePageState createState() => _HomePageState();
// }
//
// class _HomePageState extends State<PetgiverHomepage> {
//   final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
//   int _currentIndex = 0;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         title: Text(
//           '🐾 Paw Haven 🐾\nWelcome, ${widget.username}',
//           style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
//         ),
//         backgroundColor: Colors.orangeAccent,
//         leading: IconButton(
//           icon: const Icon(Icons.menu),
//           onPressed: () {
//             _scaffoldKey.currentState?.openDrawer();
//           },
//         ),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.search, color: Colors.white),
//             onPressed: () {
//               Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: SearchPage()));
//             },
//           ),
//         ],
//       ),
//       drawer: _buildCustomDrawer(),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.symmetric(horizontal: 8.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const SizedBox(height: 10),
//             _buildImageCarousel(),
//             const SizedBox(height: 10),
//             _buildAnimalOptions(),
//           ],
//         ),
//       ),
//       bottomNavigationBar: _buildBottomNavigationBar(),
//     );
//   }
//
//   Widget _buildCustomDrawer() {
//     return Drawer(
//       child: ListView(
//         padding: EdgeInsets.zero,
//         children: [
//           DrawerHeader(
//             decoration: BoxDecoration(color: Colors.pinkAccent),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Icon(Icons.pets, size: 50, color: Colors.white),
//                 const SizedBox(height: 8),
//                 Text(
//                   "🐾 Paw Haven",
//                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
//                 ),
//                 const SizedBox(height: 4),
//                 Text(
//                   "Helping paws find homes",
//                   style: TextStyle(fontSize: 12, color: Colors.white70),
//                 ),
//               ],
//             ),
//           ),
//           _buildDrawerItem(icon: Icons.pets, title: 'Add Pets', onTap: () => _navigateTo(Petaddscreen(username: widget.username))),
//           _buildDrawerItem(icon: Icons.pets, title: 'Add Strays', onTap: () => _navigateTo(Strayaddscreen(username: widget.username))),
//           _buildDrawerItem(icon: Icons.pets, title: 'Add Pet Accessories', onTap: () => _navigateTo(Accessoriesaddscreen(username: widget.username))),
//           Divider(),
//           _buildDrawerItem(icon: Icons.my_library_add_outlined, title: 'My Ads', onTap: () => _navigateTo(StoredAnimalsScreen())),
//           _buildDrawerItem(icon: Icons.request_quote, title: 'Adoption Requests', onTap: () => _navigateTo(SubmittedDetailsScreen(data: {}))),
//           Divider(),
//           _buildDrawerItem(icon: Icons.info, title: 'About', onTap: _showAboutDialog),
//           _buildDrawerItem(icon: Icons.settings, title: 'Settings', onTap: () => _navigateTo(SettingsScreen())),
//           Divider(),
//           _buildDrawerItem(icon: Icons.login, title: 'Log In', onTap: () => _navigateTo(LoginPage())),
//           _buildDrawerItem(icon: Icons.logout_outlined, title: 'Logout', onTap: () => _navigateTo(LogoutPage())),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildAnimalOptions() {
//     return Column(
//       children: [
//         _buildAnimalOption('assets/images/Pet.jpg', 'Rehome Your Pet', Petaddscreen(username: widget.username)),
//         _buildAnimalOption('assets/images/Stray.jpg', 'Find a New Home for Stray', Strayaddscreen(username: widget.username)),
//         _buildAnimalOption('assets/images/Access.jpg', 'Sell Your Pet Accessories', Accessoriesaddscreen(username: widget.username)),
//       ],
//     );
//   }
//
//   Widget _buildAnimalOption(String imagePath, String label, Widget navigateToPage) {
//     return GestureDetector(
//       onTap: () {
//         _navigateTo(navigateToPage);
//       },
//       child: Card(
//         elevation: 4.0,
//         margin: const EdgeInsets.symmetric(vertical: 8.0),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
//         child: Column(
//           children: [
//             ClipRRect(
//               borderRadius: BorderRadius.circular(12.0),
//               child: Image.asset(imagePath, fit: BoxFit.cover, height: 160, width: double.infinity),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               label,
//               textAlign: TextAlign.center,
//               style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
//             ),
//             const SizedBox(height: 8),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _navigateTo(Widget page) {
//     Navigator.push(
//       context,
//       PageTransition(type: PageTransitionType.rightToLeft, child: page),
//     );
//   }
//
//   Widget _buildImageCarousel() {
//     List<String> images = ['assets/images/Stray.jpg', 'assets/images/pp1.jpg', 'assets/images/pp2.jpg'];
//     return CarouselSlider(
//       items: images.isNotEmpty
//           ? images.map((imagePath) {
//         return ClipRRect(
//           borderRadius: BorderRadius.circular(8.0),
//           child: Image.asset(imagePath, fit: BoxFit.cover),
//         );
//       }).toList()
//           : [const Center(child: Text('No images available'))],
//       options: CarouselOptions(
//         height: 160,
//         autoPlay: true,
//         enlargeCenterPage: true,
//         aspectRatio: 16 / 9,
//         viewportFraction: 0.8,
//         enableInfiniteScroll: true,
//       ),
//     );
//   }
//
//   Widget _buildDrawerItem({required IconData icon, required String title, required VoidCallback onTap}) {
//     return ListTile(
//       leading: Icon(icon, color: Colors.orangeAccent),
//       title: Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
//       onTap: onTap,
//     );
//   }
//
//   Widget _buildBottomNavigationBar() {
//     return BottomNavigationBar(
//       type: BottomNavigationBarType.fixed,
//       backgroundColor: Colors.orangeAccent,
//       selectedItemColor: Colors.white,
//       unselectedItemColor: Colors.black54,
//       selectedFontSize: 12,
//       unselectedFontSize: 12,
//       iconSize: 24,
//       currentIndex: _currentIndex,
//       onTap: (index) {
//         setState(() => _currentIndex = index);
//         _navigateBasedOnIndex(index);
//       },
//       items: const [
//         BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
//         BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Add Here'),
//         BottomNavigationBarItem(icon: Icon(Icons.request_quote), label: 'Requests'),
//         BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
//       ],
//     );
//   }
//
//   void _navigateBasedOnIndex(int index) {
//     switch (index) {
//       case 0:
//         Navigator.popUntil(context, (route) => route.isFirst);
//         break;
//       case 1:
//         _navigateTo(AnimalTypeSelection());
//         break;
//       case 2:
//         _navigateTo(SubmittedDetailsScreen(data: {}));
//         break;
//       case 3:
//         _navigateTo(UserScreen());
//         break;
//     }
//   }
//
//   void _showAboutDialog() {
//     showDialog(
//       context: context,
//       builder: (context) => AlertDialog(
//         title: const Text('About'),
//         content: const Text('This app helps stray animals by connecting them with prospective adopters.'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.of(context).pop(),
//             child: const Text('OK'),
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:untitled4/screens/viewscreens/allanimalsview.dart';
import '../screens/AddScreen.dart';
import '../screens/LoginPage.dart';
import '../screens/LogoutPage.dart';
import '../screens/SettingsScreen.dart';
import '../screens/buyer side/searchbuttonpage.dart';
import '../screens/viewscreens/UserScreen.dart';
import 'approvereq.dart';


class PetgiverHomepage extends StatefulWidget {
  final String username;


  const PetgiverHomepage({required this.username, super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<PetgiverHomepage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  int _currentIndex = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(
          '🐾 Paw Haven 🐾\nWelcome, ${widget.username}',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.orangeAccent,
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: () {
              Navigator.push(context, PageTransition(type: PageTransitionType.rightToLeft, child: const SearchPage()));
            },
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            _buildImageCarousel(),
            const SizedBox(height: 10),
            _buildAnimalOptions(),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(color: Colors.pinkAccent),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.pets, size: 50, color: Colors.white),
                SizedBox(height: 8),
                Text(
                  "🐾 Paw Haven",style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 4),
                Text(
                  "Helping paws find homes",
                  style: TextStyle(fontSize: 15, color: Colors.white),
                ),
              ],
            ),
          ),
          _buildDrawerItem(icon: Icons.pets, title: 'Add Pets', onTap: () => _navigateTo(Petaddscreen(username: widget.username))),
          _buildDrawerItem(icon: Icons.pets, title: 'Add Strays', onTap: () => _navigateTo(Strayaddscreen(username: widget.username))),
          _buildDrawerItem(icon: Icons.pets, title: 'Add Pet Accessories', onTap: () => _navigateTo(Accessoriesaddscreen(username: widget.username))),
          const Divider(),
          _buildDrawerItem(icon: Icons.my_library_add_outlined, title: 'My Ads', onTap: () => _navigateTo(const StoredAnimalsScreen())),
          _buildDrawerItem(icon: Icons.request_quote, title: 'Adoption Requests', onTap: () => _navigateTo(const SubmittedFormsScreen()),
          //   Divider(),
          // _buildDrawerItem(icon: Icons.info, title: 'About', onTap: _showAboutDialog),
          // _buildDrawerItem(icon: Icons.settings, title: 'Settings', onTap: () => _navigateTo(SettingsScreen())),
          // Divider(),
          // _buildDrawerItem(icon: Icons.login, title: 'Log In', onTap: () => _navigateTo(LoginPage())),
          // _buildDrawerItem(icon: Icons.logout_outlined, title: 'Logout', onTap: () => _navigateTo(LogoutPage())),
          )],
      ),
    );
  }

  Widget _buildAnimalOptions() {
    return Column(
      children: [
        _buildAnimalOption('assets/images/Pet.jpg', 'Rehome Your Pet', Petaddscreen(username: widget.username)),
        _buildAnimalOption('assets/images/Stray.jpg', 'Find a New Home for Stray', Strayaddscreen(username: widget.username)),
        _buildAnimalOption('assets/images/Access.jpg', 'Sell Your Pet Accessories', Accessoriesaddscreen(username: widget.username)),
      ],
    );
  }

  Widget _buildAnimalOption(String imagePath, String label, Widget navigateToPage) {
    return GestureDetector(
      onTap: () {
        _navigateTo(navigateToPage);
      },
      child: Card(
        elevation: 4.0,
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12.0),
              child: Image.asset(imagePath, fit: BoxFit.cover, height: 120, width: 120),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  label,
                  textAlign: TextAlign.left,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateTo(Widget page) {
    Navigator.push(
      context,
      PageTransition(type: PageTransitionType.rightToLeft, child: page),
    );
  }

  Widget _buildImageCarousel() {
    List<String> images = ['assets/images/Stray.jpg', 'assets/images/pp1.jpg', 'assets/images/pp2.jpg'];
    return CarouselSlider(
      items: images.isNotEmpty
          ? images.map((imagePath) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(5.0),
          child: Image.asset(imagePath, fit: BoxFit.cover),
        );
      }).toList()
          : [const Center(child: Text('No images available'))],
      options: CarouselOptions(
        height: 220,
        autoPlay: true,
        enlargeCenterPage: true,
        aspectRatio: 16 / 9,
        viewportFraction: 0.8,
        enableInfiniteScroll: true,
      ),
    );
  }

  Widget _buildDrawerItem({required IconData icon, required String title, required VoidCallback onTap}) {
    return ListTile(
      leading: Icon(icon, color: Colors.orangeAccent),
      title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
      onTap: onTap,
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.orangeAccent,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.black54,
      selectedFontSize: 13,
      unselectedFontSize: 12,
      iconSize: 24,
      currentIndex: _currentIndex,
      onTap: (index) {
        setState(() => _currentIndex = index);
        _navigateBasedOnIndex(index);
      },
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.add_box), label: 'Add Here'),
        BottomNavigationBarItem(icon: Icon(Icons.request_quote), label: 'Requests'),
        BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
      ],
    );
  }

  void _navigateBasedOnIndex(int index) {
    switch (index) {
      case 0:
        _navigateTo(const PetgiverHomepage(username: '', )); {}
        break;
      case 1:
        _navigateTo(const AnimalTypeSelection());
        break;
      case 2:
        _navigateTo(const SubmittedFormsScreen());
        break;
      case 3:
        _navigateTo(const UserScreen());
        break;
    }
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('About'),
        content: const Text('This app helps stray animals by connecting them with prospective adopters.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}



class Petaddscreen extends StatelessWidget {
  const Petaddscreen({super.key, required  username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pass the pet Forward', style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.orangeAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            tooltip: 'View Stored Animals',
            onPressed: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => const StoredAnimalsScreen(),
              ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // const Text(
            //   'Pass the Paw Forward',
            //   style: TextStyle,fontSize: 18,fontWeight: FontWeight.w600,
            //   ),
            // ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _buildAnimalOption(
                      context, 'assets/images/Pet.jpg', 'Pet', 'Rehome Your Pet'),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimalOption(
      BuildContext context, String imagePath, String type, String description) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(
          builder: (context) => GalleryAccess(animalType: type),
        ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(
                imagePath, height: 80, width: double.infinity, fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    type, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                  ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description, style: const TextStyle(fontSize: 14, color: Colors.grey,
                  ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Strayaddscreen extends StatelessWidget {
  const Strayaddscreen({super.key, required  username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pass the stary Forward', style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.pinkAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            tooltip: 'View Stored Animals',
            onPressed: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => const StoredAnimalsScreen(),
              ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // const Text(
            //   'Pass the Paw Forward',
            //   style: TextStyle,fontSize: 18,fontWeight: FontWeight.w600,
            //   ),
            // ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [

                  _buildAnimalOption(
                      context, 'assets/images/Stray.jpg', 'Stray', 'Find a New Home for Stray'),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimalOption(
      BuildContext context, String imagePath, String type, String description) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(
          builder: (context) => GalleryAccess(animalType: type),
        ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(
                imagePath, height: 80, width: double.infinity, fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    type, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                  ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description, style: const TextStyle(fontSize: 14, color: Colors.grey,
                  ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Accessoriesaddscreen extends StatelessWidget {
  const Accessoriesaddscreen({super.key, required  username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Sell your resuable pet accessories', style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.pinkAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            tooltip: 'View Stored Animals',
            onPressed: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => const StoredAnimalsScreen(),
              ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // const Text(
            //   'Pass the Paw Forward',
            //   style: TextStyle,fontSize: 18,fontWeight: FontWeight.w600,
            //   ),
            // ),
            const SizedBox(height: 16),
            Expanded(
              child: ListView(
                children: [
                  _buildAnimalOption(context, 'assets/images/Access.jpg', 'Accessory', 'Sell your resuable pet accessories'),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimalOption(
      BuildContext context, String imagePath, String type, String description) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(
          builder: (context) => GalleryAccess(animalType: type),
        ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(
                imagePath, height: 80, width: double.infinity, fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    type, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold,
                  ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    description, style: const TextStyle(fontSize: 14, color: Colors.grey,
                  ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
