import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('stray_haven.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, fileName);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT UNIQUE NOT NULL,
        city TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL
      )
    ''');
  }

  Future<int> registerUser(String name, String phone, String city, String password, String role) async {
    final db = await instance.database;
    return await db.insert('users', {
      'name': name,
      'phone': phone,
      'city': city,
      'password': password,
      'role': role
    });
  }

  Future<Map<String, dynamic>?> loginUser(String phone, String password) async {
    final db = await instance.database;
    List<Map<String, dynamic>> users = await db.query(
      'users',
      where: 'phone = ? AND password = ?',
      whereArgs: [phone, password],
    );
    return users.isNotEmpty ? users.first : null;
  }

  Future<bool> isContactRegistered(String phone) async {
    final db = await instance.database;
    List<Map<String, dynamic>> result = await db.query('users', where: 'phone = ?', whereArgs: [phone]);
    return result.isNotEmpty;
  }
}
