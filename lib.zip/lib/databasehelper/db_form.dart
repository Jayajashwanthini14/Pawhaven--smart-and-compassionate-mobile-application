import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';


class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;

  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'stray_haven.db');

    return await openDatabase(
      path,
      version: 2,
      onCreate: (db, version) async {
        await _createTables(db);
      },
      // onUpgrade: (db, oldVersion, newVersion) async {
      //   if (oldVersion < 2) {
      //     await db.execute('''
      //       CREATE TABLE IF NOT EXISTS adoption_requests (
      //         id INTEGER PRIMARY KEY AUTOINCREMENT,
      //         name TEXT NOT NULL,
      //         contact TEXT NOT NULL,
      //         id INTEGER,
      //         status TEXT DEFAULT 'pending'
      //       )
      //     ''');
      //   }
      // },
    );
  }

  Future<void> _createTables(Database db) async {
    await db.execute('''
      CREATE TABLE adoption_form (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact TEXT NOT NULL,
        address TEXT NOT NULL,
        homeType TEXT,
        ownershipStatus TEXT,
        isFenced INTEGER,
        hasOwnedPet INTEGER,
        reasonForAdoption TEXT,
        agreeToRules INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE adoption_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact TEXT NOT NULL,
        pet_id INTEGER,
        status TEXT DEFAULT 'pending'
      )
    ''');
  }

  Future<int> insertAdoptionForm(Map<String, dynamic> formData) async {
    try {
      final db = await database;
      return await db.insert('adoption_form', formData);
    } catch (e) {
      print('Error inserting adoption form: $e');
      return -1;
    }
  }

  Future<List<Map<String, dynamic>>> fetchAllForms() async {
    final db = await database;
    return await db.query('adoption_form');
  }
  // Future<void> _fetchRequests() async {
  //   final requests = await DatabaseHelper().fetchAllForms();
  //   print("Fetched Requests: $requests"); // Debugging Line
  //   setState(() {
  //     _requests = requests;
  //   });
  // }

  Future<int> insertAdoptionRequest(Map<String, dynamic> data) async {
    try {
      final db = await database;
      data['status'] = 'pending';
      return await db.insert('adoption_requests', data);
    } catch (e) {
      print('Error inserting adoption request: $e');
      return -1;
    }
  }
  Future<int> updateRequestStatus(int requestId, String newStatus) async {
    final db = await database; // Ensure we await the database getter
    return await db.update(
      'adoption_requests',
      {'status': newStatus},
      where: 'id = ?',
      whereArgs: [requestId],
    );
  }

  Future<List<Map<String, dynamic>>> getPendingRequests(int petGiverId) async {
    final db = await database; // Fix: Await the database instance
    return await db.query('adoption_requests', where: 'status = ?', whereArgs: ['pending']);
  }

  Future<int> deleteRequest(int requestId) async {
    final db = await database; // Fix: Await the database instance
    return await db.delete(
      'adoption_requests',
      where: 'id = ?',
      whereArgs: [requestId],
    );
  }
  Future<void> printAllRequests() async {
    final db = await database;
    final List<Map<String, dynamic>> requests = await db.query('adoption_requests');

    for (var request in requests) {
      print('Request: $request');
    }
  }







// Future<int> updateRequestStatus(int requestId, String newStatus) async {
  //   final db = await database;
  //   return await db.update(
  //     'adoption_requests',
  //     {'status': newStatus},
  //     where: 'id = ?',
  //     whereArgs: [requestId],
  //   );
  // }
  //
  // Future<List<Map<String, dynamic>>> getPendingRequests() async {
  //   final db = await database;
  //   return await db.query('adoption_requests', where: 'status = ?', whereArgs: ['pending']);
  // }
  //
  // Future<List<Map<String, dynamic>>> getRequestsByStatus(String status) async {
  //   final db = await database;
  //   return await db.query('adoption_requests', where: 'status = ?', whereArgs: [status]);
  // }
  //
  // Future<int> deleteRequest(int requestId) async {
  //   final db = await database;
  //   return await db.delete(
  //     'adoption_requests',
  //     where: 'id = ?',
  //     whereArgs: [requestId],
  //   );
  // }
}

// Future<List<Map<String, dynamic>>> getPendingRequests(int pet_id) async {
//   final db = await database;
//   return await db.query(
//     'adoption_requests',
//     where: 'pet_giver_id = ? AND status = ?',
//     whereArgs: [pet_id, 'pending'],
//   );
// }

//
// // import 'package:sqflite/sqflite.dart';
// // import 'package:path/path.dart';
// //
// // class DatabaseHelper {
// //   static final DatabaseHelper _instance = DatabaseHelper._internal();
// //
// //   factory DatabaseHelper() => _instance;
// //
// //   static Database? _database;
// //
// //   DatabaseHelper._internal();
// //
// //   Future<Database> get database async {
// //     if (_database != null) return _database!;
// //     _database = await _initDatabase();
// //     return _database!;
// //   }
// //
// //   Future<Database> _initDatabase() async {
// //     String path = join(await getDatabasesPath(), 'stray_haven.db');
// //
// //     return await openDatabase(
// //       path,
// //       version: 2,
// //       onCreate: (db, version) async {
// //         await _createTables(db);
// //       },
// //     );
// //   }
// //
// //   Future<void> _createTables(Database db) async {
// //     await db.execute('''
// //       CREATE TABLE adoption_form (
// //         id INTEGER PRIMARY KEY AUTOINCREMENT,
// //         name TEXT NOT NULL,
// //         contact TEXT NOT NULL,
// //         address TEXT NOT NULL,
// //         homeType TEXT,
// //         ownershipStatus TEXT,
// //         isFenced INTEGER,
// //         hasOwnedPet INTEGER,
// //         reasonForAdoption TEXT,
// //         agreeToRules INTEGER
// //       )
// //     ''');
// //
// //     await db.execute('''
// //       CREATE TABLE adoption_requests (
// //         id INTEGER PRIMARY KEY AUTOINCREMENT,
// //         name TEXT NOT NULL,
// //         contact TEXT NOT NULL,
// //         pet_id INTEGER,
// //         status TEXT DEFAULT 'pending'
// //       )
// //     ''');
// //   }
// //
// //   // Insert adoption form
// //   Future<int> insertAdoptionForm(Map<String, dynamic> formData) async {
// //     try {
// //       final db = await database;
// //       return await db.insert('adoption_form', formData);
// //     } catch (e) {
// //       print('Error inserting adoption form: $e');
// //       return -1;
// //     }
// //   }
// //
// //   // Fetch all adoption forms
// //   Future<List<Map<String, dynamic>>> fetchAllForms() async {
// //     final db = await database;
// //     return await db.query('adoption_form');
// //   }
// //
// //   // Insert adoption request
// //   Future<int> insertAdoptionRequest(Map<String, dynamic> data) async {
// //     try {
// //       final db = await database;
// //       data['status'] = 'pending';
// //       return await db.insert('adoption_requests', data);
// //     } catch (e) {
// //       print('Error inserting adoption request: $e');
// //       return -1;
// //     }
// //   }
// //
// //   // Update adoption request status
// //   Future<int> updateRequestStatus(int requestId, String newStatus) async {
// //     final db = await database;
// //     return await db.update(
// //       'adoption_requests',
// //       {'status': newStatus},
// //       where: 'id = ?',
// //       whereArgs: [requestId],
// //     );
// //   }
// //
// //   // Get all pending requests
// //   Future<List<Map<String, dynamic>>> getPendingRequests() async {
// //     final db = await database;
// //     return await db.query('adoption_requests', where: 'status = ?', whereArgs: ['pending']);
// //   }
// //
// //   // Delete a request
// //   Future<int> deleteRequest(int requestId) async {
// //     final db = await database;
// //     return await db.delete(
// //       'adoption_requests',
// //       where: 'id = ?',
// //       whereArgs: [requestId],
// //     );
// //   }
// //
// //   // Debugging: Print all adoption requests
// //   Future<void> printAllRequests() async {
// //     final db = await database;
// //     final List<Map<String, dynamic>> requests = await db.query('adoption_requests');
// //
// //     for (var request in requests) {
// //       print('Request: $request');
// //     }
// //   }
// // }
// // Future<int> insertAdoptionRequest(Map<String, dynamic> requestData) async {
// //   var database;
// //   final db = await database;
// //   return await db.insert('AdoptionRequests', requestData);
// // }
// import 'package:sqflite/sqflite.dart';
// import 'package:path/path.dart';
//
// class DatabaseHelper {
//   static final DatabaseHelper _instance = DatabaseHelper._internal();
//
//   factory DatabaseHelper() => _instance;
//
//   static Database? _database;
//
//   DatabaseHelper._internal();
//
//   Future<Database> get database async {
//     if (_database != null) return _database!;
//     _database = await _initDatabase();
//     return _database!;
//   }
//
//   Future<Database> _initDatabase() async {
//     String path = join(await getDatabasesPath(), 'stray_haven.db');
//
//     return await openDatabase(
//       path,
//       version: 2,
//       onCreate: (db, version) async {
//         await _createTables(db);
//       },
//       onUpgrade: (db, oldVersion, newVersion) async {
//         if (oldVersion < newVersion) {
//           // Handle schema upgrades here if needed
//         }
//       },
//     );
//   }
//
//   Future<void> _createTables(Database db) async {
//     await db.execute('''
//       CREATE TABLE IF NOT EXISTS adoption_form (
//         id INTEGER PRIMARY KEY AUTOINCREMENT,
//         name TEXT NOT NULL,
//         contact TEXT NOT NULL,
//         address TEXT NOT NULL,
//         homeType TEXT,
//         ownershipStatus TEXT,
//         isFenced INTEGER,
//         hasOwnedPet INTEGER,
//         reasonForAdoption TEXT,
//         agreeToRules INTEGER
//       )
//     ''');
//
//     await db.execute('''
//       CREATE TABLE IF NOT EXISTS adoption_requests (
//         id INTEGER PRIMARY KEY AUTOINCREMENT,
//         name TEXT NOT NULL,
//         contact TEXT NOT NULL,
//         pet_id INTEGER,
//         status TEXT DEFAULT 'pending'
//       )
//     ''');
//   }
//
//   // Insert adoption form
//   Future<int> insertAdoptionForm(Map<String, dynamic> formData) async {
//     try {
//       final db = await database;
//       return await db.insert('adoption_form', formData);
//     } catch (e) {
//       print('Error inserting adoption form: $e');
//       return -1;
//     }
//   }
//
//   // Fetch all adoption forms
//   Future<List<Map<String, dynamic>>> fetchAllForms() async {
//     final db = await database;
//     return await db.query('adoption_form');
//   }
//
//   // Insert adoption request (Fixed)
//   Future<int> insertAdoptionRequest(Map<String, dynamic> requestData) async {
//     try {
//       final db = await database;
//       requestData['status'] = 'pending';
//       return await db.insert('adoption_requests', requestData);
//     } catch (e) {
//       print('Error inserting adoption request: $e');
//       return -1;
//     }
//   }
//
//   // Update adoption request status
//   Future<int> updateRequestStatus(int requestId, String newStatus) async {
//     final db = await database;
//     return await db.update(
//       'adoption_requests',
//       {'status': newStatus},
//       where: 'id = ?',
//       whereArgs: [requestId],
//     );
//   }
//
//   // Get all pending requests
//   Future<List<Map<String, dynamic>>> getPendingRequests() async {
//     final db = await database;
//     return await db.query('adoption_requests', where: 'status = ?', whereArgs: ['pending']);
//   }
//
//   // Delete a request
//   Future<int> deleteRequest(int requestId) async {
//     final db = await database;
//     return await db.delete(
//       'adoption_requests',
//       where: 'id = ?',
//       whereArgs: [requestId],
//     );
//   }
//
//   // Debugging: Print all adoption requests
//   Future<void> printAllRequests() async {
//     final db = await database;
//     final List<Map<String, dynamic>> requests = await db.query('adoption_requests');
//
//     for (var request in requests) {
//       print('Request: $request');
//     }
//   }
//
//   // Close database connection
//   Future<void> closeDatabase() async {
//     final db = await database;
//     await db.close();
//   }
// }
// // Fetch all adoption forms
// Future<List<Map<String, dynamic>>> fetchAllForms() async {
//   var database;
//   final db = await database;
//   return await db.query('adoption_form'); // Query all records from the adoption_form table
// }
