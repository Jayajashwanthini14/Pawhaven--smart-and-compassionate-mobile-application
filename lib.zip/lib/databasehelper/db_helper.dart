import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _database;


  factory DatabaseHelper() => instance;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    return openDatabase(
      join(dbPath, 'app_database.db'),
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            contact TEXT NOT NULL UNIQUE,
            city TEXT NOT NULL,
            password TEXT NOT NULL
          )
       '''
        );

        await db.execute('''
          CREATE TABLE animals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            animalType TEXT,
            title TEXT,
            description TEXT,
            price TEXT,
            reason TEXT,
            productName TEXT,
            yearsUsed INTEGER,
            imagePath TEXT,
            favorite INTEGER DEFAULT 0,
            type TEXT NOT NULL,
            gender TEXT,       
            size TEXT,         
            breed TEXT,       
            location TEXT
          )
        ''');
      },
      version: 1,
    );
  }

  Future<int> registerUser(String fullName, String contact, String city, String password) async {
    final db = await database;
    try {
      return await db.insert('users', {
        'full_name': fullName,
        'contact': contact,
        'city': city,
        'password': password,
      });
    } catch (e) {
      print('Error registering user: $e');
      return -1;
    }
  }



  Future<bool> isContactRegistered(String contact) async {
    final db = await database;
    try {
      final result = await db.query(
        'users',
        where: 'contact = ?', whereArgs: [contact],
      );
      return result.isNotEmpty;
    } catch (e) {
      print('Error checking contact: $e');
      return false;
    }
  }
  Future<bool> validateUser(String phone, String password) async {
    final db = await database;
    final List<Map<String, dynamic>> result = await db.query(
      'users',
      where: 'contact = ? AND password = ?',
      whereArgs: [phone, password],
    );//new

    return result.isNotEmpty;
  }
  // Future<bool> validateUser(String contact, String password) async {
  //   final db = await database;
  //   try {
  //     final result = await db.query(
  //       'users',
  //       where: 'contact = ? AND password = ?',
  //       whereArgs: [contact, password],
  //     );
  //     return result.isNotEmpty;
  //   } catch (e) {
  //     print('Error validating user: $e');
  //     return false;
  //   }
  // }

  // Future<bool> validateUser(String full_name, String password) async {
  //   final db = await database;
  //   try {
  //     final result = await db.query(
  //       'users',
  //       where: 'full_name = ? AND password = ?',
  //       whereArgs: [full_name, password],
  //     );
  //     return result.isNotEmpty;
  //   } catch (e) {
  //     print('Error validating user: $e');
  //     return false;
  //   }
  // }
  //
  // Future<bool> isfull_nameRegistered(String contact) async {
  //   final db = await database;
  //   try {
  //     final result = await db.query(
  //       'users',
  //       where: 'full_name = ?', whereArgs: [contact],
  //     );
  //     return result.isNotEmpty;
  //   } catch (e) {
  //     print('Error checking contact: $e');
  //     return false;
  //   }
  // }




  Future<void> insertAnimal(Map<String, dynamic> animal) async {
    final db = await database;
    await db.insert('animals', animal);
  }

  Future<List<Map<String, dynamic>>> fetchAnimals() async {
    final db = await database;
    return await db.query('animals');
  }

  Future<List<Map<String, dynamic>>> fetchFavorites() async {
    final db = await database;
    return await db.query(
      'animals',
      where: 'favorite = ?',
      whereArgs: [1],
    );
  }

  Future<int> updateFavoriteStatus(int id, bool isFavorite) async {
    final db = await database;
    return await db.update(
      'animals',
      {'favorite': isFavorite ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteAnimal(int id) async {
    final db = await database;
    return await db.delete('animals', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clearAllAnimals() async {
    final db = await database;
    await db.delete('animals');
  }
  Future<List<Map<String, dynamic>>> fetchAnimalsByType(String animalType) async {
    final db = await database;
    return await db.query(
      'animals',
      where: 'animalType = ?',
      whereArgs: [animalType],
      orderBy: 'id DESC',
    );
  }
  Future<void> addToFavorites(Map<String, dynamic> pet) async {
    final db = await database;
    await db.insert('favorites', pet, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> fetchItemsByType(String type) async {
    final db = await database;
    return await db.query(
      'items',
      where: 'type = ?',
      whereArgs: [type],
    );
  }

}

Future<bool> validateUser(String contact, String password) async {
  var database;
  final db = await database;  //final db = await database;
  final result = await db.query(
    'users',
    where: 'contact = ? AND password = ?',
    whereArgs: [contact, password],
  );
  return result.isNotEmpty;
}//loginpagedb



