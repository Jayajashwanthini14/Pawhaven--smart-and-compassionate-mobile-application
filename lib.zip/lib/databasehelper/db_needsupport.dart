import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';



class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = await getDatabasesPath();
    return await openDatabase(
      join(path, 'pet_shelter.db'),
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE shelter_support (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            petName TEXT,
            petType TEXT,
            petAge TEXT,
            healthStatus TEXT,
            shelterType TEXT,
            shelterDuration TEXT,
            ownerName TEXT,
            ownerContact TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE visits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            visitDate TEXT,
            visitTime TEXT,
            shelterSupportId INTEGER,
            FOREIGN KEY(shelterSupportId) REFERENCES shelter_support(id)
          )
        ''');
      },
      version: 1,
    );
  }

  Future<void> insertsupport(Map<String, dynamic> data) async {
    final db = await database;
    await db.insert('shelter_support', data);
  }

  Future<void> insertVisit(Map<String, dynamic> data) async {
    final db = await database;
    await db.insert('visits', data);
  }

  Future<List<Map<String, dynamic>>> getsupport() async {
    final db = await database;
    return await db.query('shelter_support');
  }

  Future<void> deletesupport(int id) async {
    final db = await database;
    await db.delete('shelter_support', where: 'id = ?', whereArgs: [id]);
  }
}
